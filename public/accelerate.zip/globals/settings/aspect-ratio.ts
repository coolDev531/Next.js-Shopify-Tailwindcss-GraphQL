export const aspectRatio = {
  type: "select" as const,
  id: "aspect_ratio",
  default: "col-span-12",
  label: "Aspect Ratio",
  options: [
    {
      value: "9-16",
      label: "Story Format",
    },
    {
      value: "1-1",
      label: "Square",
    },
    {
      value: "4-3",
      label: "4/3 TV Format",
    },
    {
      value: "3-2",
      label: "3/2 Smartphone",
    },
    {
      value: "16-9",
      label: "16-9 Widescreen",
    },
    {
      value: "21-9",
      label: "21-9 Ultra Widescreen",
    },
  ],
};
