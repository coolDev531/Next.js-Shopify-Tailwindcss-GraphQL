export const sectionGlobals = {
  colorScheme: {
    type: "select" as const,
    id: "color_scheme",
    default: "bg-theme-bg text-theme-text color-inherit",
    options: [
      {
        value: "bg-theme-bg text-theme-text color-inherit",
        label: "Inherit from parent/theme",
      },
      {
        value: "bg-theme-bg text-theme-text color-group-1",
        label: "Color group 1",
      },
      {
        value: "bg-theme-bg text-theme-text color-group-2",
        label: "Color group 2",
      },
      {
        value: "bg-theme-bg text-theme-text color-group-3",
        label: "Color group 3",
      },
    ],
    label: "Color scheme",
  },
  responsiveVisibility: {
    type: "radio" as const,
    id: "responsive_visibility",
    label: "Responsive Visibility",
    default: "responsive",
    options: [
      {
        value: "responsive",
        label: "Mobile & Desktop",
      },
      {
        value: "md:hidden",
        label: "Mobile only",
      },
      {
        value: "max-md:hidden",
        label: "Desktop only",
      },
    ],
  },
  topPadding: {
    type: "select" as const,
    id: "padding_top",
    default: "pt-0",
    options: [
      {
        value: "pt-0",
        label: "None",
      },
      {
        value: "pt-sm",
        label: "Small",
      },
      {
        value: "pt-md",
        label: "Medium",
      },
      {
        value: "pt-lg",
        label: "Large",
      },
    ],
    label: "Top Padding",
  },
  bottomPadding: {
    type: "select" as const,
    id: "padding_bottom",
    default: "pb-0",
    options: [
      {
        value: "pb-0",
        label: "None",
      },
      {
        value: "pb-sm",
        label: "Small",
      },
      {
        value: "pb-md",
        label: "Medium",
      },
      {
        value: "pb-lg",
        label: "Large",
      },
    ],
    label: "Bottom Padding",
  },
  sectionLayout: {
    type: "radio" as const,
    id: "section_layout",
    label: "Section Layout",
    default: "container-bg-full",
    options: [
      {
        value: "container-bg-full",
        label: "Container",
      },
      {
        value: "fullwidth",
        label: "Fullwidth",
      },
    ],
  },
  marginBottom: {
    type: "range" as const,
    id: "margin_bottom",
    label: "Margin Bottom",
    default: 0,
    min: -6,
    max: 64,
    step: 2,
    unit: "px",
  },
};
