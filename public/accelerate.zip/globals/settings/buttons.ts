export const buttonSettings = {
  text: {
    type: "text" as const,
    id: "button__text",
    label: "Button Text",
  },
  url: {
    type: "url" as const,
    id: "button__url",
    label: "Button Url",
  },
  style: {
    type: "radio" as const,
    id: "button__style",
    label: "Button Style",
    default: "button-primary",
    options: [
      {
        value: "button-primary",
        label: "Primary",
      },
      {
        value: "button-primary--outline",
        label: "Primary Outline",
      },
      {
        value: "button-secondary",
        label: "Secondary",
      },
      {
        value: "button-secondary--outline",
        label: "Secondary Outline",
      },
    ],
  },
  primary: {
    header: {
      type: "header" as const,
      content: "Primary Button",
    },
    text: {
      type: "text" as const,
      id: "button_primary__text",
      label: "Text",
    },
    url: {
      type: "url" as const,
      id: "button_primary__url",
      label: "Url",
    },
    style: {
      type: "radio" as const,
      id: "button_primary__style",
      label: "Style",
      default: "button-primary",
      options: [
        {
          value: "button-primary",
          label: "Primary",
        },
        {
          value: "button-primary--outline",
          label: "Primary Outline",
        },
        {
          value: "button-secondary",
          label: "Secondary",
        },
        {
          value: "button-secondary--outline",
          label: "Secondary Outline",
        },
      ],
    },
  },
  secondary: {
    header: {
      type: "header" as const,
      content: "Secondary Button",
    },
    text: {
      type: "text" as const,
      id: "button_secondary__text",
      label: "Text",
    },
    url: {
      type: "url" as const,
      id: "button_secondary__url",
      label: "Url",
    },
    style: {
      type: "radio" as const,
      id: "button_secondary__style",
      label: "Style",
      default: "button-primary",
      options: [
        {
          value: "button-primary",
          label: "Primary",
        },
        {
          value: "button-primary--outline",
          label: "Primary Outline",
        },
        {
          value: "button-secondary",
          label: "Secondary",
        },
        {
          value: "button-secondary--outline",
          label: "Secondary Outline",
        },
      ],
    },
  },
};

export const buttons = {
  primary: [
    {
      type: "header" as const,
      content: "Primary Button",
    },
    {
      type: "text" as const,
      id: "button_primary__text",
      label: "Text",
    },
    {
      type: "url" as const,
      id: "button_primary__url",
      label: "Url",
    },
    {
      type: "radio" as const,
      id: "button_primary__style",
      label: "Style",
      default: "button-primary",
      options: [
        {
          value: "button-primary",
          label: "Primary",
        },
        {
          value: "button-primary--outline",
          label: "Primary Outline",
        },
        {
          value: "button-secondary",
          label: "Secondary",
        },
        {
          value: "button-secondary--outline",
          label: "Secondary Outline",
        },
      ],
    },
  ],
  secondary: [
    {
      type: "header" as const,
      content: "Secondary Button",
    },
    {
      type: "text" as const,
      id: "button_secondary__text",
      label: "Text",
    },
    {
      type: "url" as const,
      id: "button_secondary__url",
      label: "Url",
    },
    {
      type: "radio" as const,
      id: "button_secondary__style",
      label: "Style",
      default: "button-primary--outline",
      options: [
        {
          value: "button-primary",
          label: "Primary",
        },
        {
          value: "button-primary--outline",
          label: "Primary Outline",
        },
        {
          value: "button-secondary",
          label: "Secondary",
        },
        {
          value: "button-secondary--outline",
          label: "Secondary Outline",
        },
      ],
    },
  ],
};
