let timeout: NodeJS.Timeout = null;

export const initTooltip = () => {
  const tooltips = document.querySelectorAll<HTMLElement>("[data-tooltip]:not([data-initiated])");

  tooltips.forEach((tooltip) => {
    tooltip.setAttribute("data-initiated", "");

    tooltip.addEventListener("mouseover", handleHover);
    tooltip.addEventListener("mouseleave", handleExit);
  });
};

const handleHover = (event: MouseEvent) => {
  const trigger = event.currentTarget as HTMLElement;
  const tooltip = document.querySelector<HTMLElement>("[data-tooltip-display]");
  const content = trigger.dataset.tooltip;
  const { left, right, width, height, top, bottom } = trigger.getBoundingClientRect();
  if (timeout) {
    clearTimeout(timeout);
  }

  tooltip.style.left = `${left}px`;
  tooltip.style.right = `${right}px`;
  tooltip.style.width = `${width}px`;
  tooltip.style.height = `${height}px`;
  tooltip.style.top = `${top}px`;
  tooltip.style.bottom = `${bottom}px`;
  tooltip.style.opacity = `1`;
  tooltip.dataset.tooltipDisplay = content;
};

const handleExit = (event: MouseEvent) => {
  const tooltip = document.querySelector<HTMLElement>("[data-tooltip-display]");
  timeout = setTimeout(
    () => {
      tooltip.style.opacity = "";

      setTimeout(
        () => {
          tooltip.style.left = "-9999px";
          tooltip.style.right = "";
          tooltip.style.top = "-9999px";
          tooltip.style.bottom = "";
          tooltip.style.width = "0";
          tooltip.style.height = "0";
          tooltip.dataset.tooltipDisplay = "";
        },
        150
      );
    },
    150
  );
};
