import clsx from "clsx";
import { scrollToX } from "globals/utils/utils";
import { FC, useCallback, useEffect, useRef, useState } from "react";

export const useWindowSize = () => {
  const [width, setWidth] = useState(window.innerWidth);
  const [height, setHeight] = useState(window.innerWidth);

  useEffect(() => {
    const handleResize = () => {
      setWidth(window.innerWidth);
      setHeight(window.innerHeight);
    };
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return { width, height };
};

export const ScrollBarButtons: FC<{ itemCount: number }> = ({ itemCount }) => {
  const sliderNavRef = useRef<HTMLDivElement>(null);
  const [showPrevButton, setShowPrevButton] = useState(false);
  const [showNextButton, setShowNextButton] = useState(false);
  const { width } = useWindowSize();

  const handleScroll = useCallback(() => {
    const scrollContainer = sliderNavRef.current!.parentElement as HTMLElement;
    const { scrollWidth, scrollLeft, offsetWidth } = scrollContainer;
    setShowPrevButton(scrollLeft !== 0);
    setShowNextButton(scrollWidth !== offsetWidth && scrollLeft + offsetWidth !== scrollWidth);
  }, []);

  const handleClickPrev = useCallback((e) => {
    const scrollContainer = sliderNavRef.current!.parentElement as HTMLElement;
    const { scrollWidth, scrollLeft } = scrollContainer;
    const itemWidth = scrollWidth / itemCount;
    const currentScrollIndex = Math.round(scrollLeft / itemWidth);

    scrollToX(220, Math.max(itemWidth * (currentScrollIndex - 1), 0), scrollContainer);
  }, [itemCount]);

  const handleClickNext = useCallback((e) => {
    const scrollContainer = sliderNavRef.current!.parentElement as HTMLElement;
    const { scrollWidth, scrollLeft, offsetWidth } = scrollContainer;
    const itemWidth = scrollWidth / itemCount;
    const currentScrollIndex = Math.round(scrollLeft / itemWidth);

    scrollToX(
      220,
      Math.min(itemWidth * (currentScrollIndex + 1), scrollWidth - offsetWidth),
      scrollContainer
    );
  }, [itemCount]);

  useEffect(() => {
    const scrollContainer = sliderNavRef.current!.parentElement as HTMLElement;

    handleScroll();
    scrollContainer.addEventListener("scroll", handleScroll);

    return () => {
      scrollContainer.removeEventListener("scroll", handleScroll);
    };
  }, [handleScroll, width]);

  return (
    <div ref={sliderNavRef} className="pointer-events-none absolute inset-0 z-20">
      <button
        className={clsx(
          "group pointer-events-none absolute top-1/2 left-0 flex -translate-y-1/2 rotate-180 items-center justify-center p-2 opacity-0 hfa:pointer-events-auto hfa:opacity-100 2xl:left-[unset] 2xl:right-full [.scroll-container:hover_&]:pointer-events-auto [.scroll-container:hover_&]:opacity-100",
          showPrevButton ? "" : "!opacity-0"
        )}
        type="button"
        onClick={handleClickPrev}
      >
        <span className="sr-only">Show previous</span>
        <i className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-900/70 text-white backdrop-blur">
          <svg
            className="ml-1 h-2 w-2 stroke-white stroke-2 md:h-2.5 md:w-2.5"
            fill="none"
            viewBox="0 0 10 10"
            aria-hidden="true"
          >
            <path className="opacity-0 transition group-hover:opacity-100" d="M0 5h7"></path>
            <path className="transition group-hover:translate-x-[3px]" d="M1 1l4 4-4 4"></path>
          </svg>
        </i>
      </button>

      <button
        className={clsx(
          "group pointer-events-none absolute top-1/2 right-0 flex -translate-y-1/2 items-center justify-center p-2 opacity-0 hfa:pointer-events-auto hfa:opacity-100 2xl:right-[unset] 2xl:left-full [.scroll-container:hover_&]:pointer-events-auto [.scroll-container:hover_&]:opacity-100",
          showNextButton ? "" : "!opacity-0"
        )}
        type="button"
        onClick={handleClickNext}
      >
        <span className="sr-only">Show next</span>
        <i className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-900/70 text-white backdrop-blur">
          <svg
            className="ml-1 h-2 w-2 stroke-white stroke-2 md:h-2.5 md:w-2.5"
            fill="none"
            viewBox="0 0 10 10"
            aria-hidden="true"
          >
            <path className="opacity-0 transition group-hover:opacity-100" d="M0 5h7"></path>
            <path className="transition group-hover:translate-x-[3px]" d="M1 1l4 4-4 4"></path>
          </svg>
        </i>
      </button>
    </div>
  );
};

export const ScrollBar: FC<{ itemCount?: number; showCount?: boolean }> = ({
  itemCount,
  showCount,
}) => {
  const [showScrollbar, setShowScrollbar] = useState(true);
  const scrollbarRef = useRef<HTMLDivElement>(null);
  const [pointerPosition, setPointerPosition] = useState<{
    startX: number | null;
    startLeft: number | null;
  }>({ startX: null, startLeft: 0 });
  const [scrollbarProps, setScrollbarProps] = useState({ width: 0, left: 0 });
  const { width } = useWindowSize();

  const handleScrollEvent = useCallback(() => {
    const scrollbarElement = scrollbarRef.current;
    if (!scrollbarElement) return;

    const scrollContainer = scrollbarElement.parentElement as HTMLElement;
    const containerWidth = scrollbarElement.offsetWidth;
    const { scrollWidth, scrollLeft } = scrollContainer;

    if (pointerPosition.startX === null && width) {
      setScrollbarProps({
        width: scrollContainer.offsetWidth / scrollWidth,
        left: (scrollLeft / scrollWidth) * containerWidth,
      });
    }
  }, [pointerPosition.startX, width]);

  const handlePointerDown = useCallback((e) => {
    if (pointerPosition.startX === null) {
      e.preventDefault();
      e.stopPropagation();
      setPointerPosition({ startX: e.clientX, startLeft: scrollbarProps.left });
      document.body.classList.add("[&_*]:!pointer-events-none", "!cursor-grabbing");
      const scrollContainer = scrollbarRef.current!.parentElement as HTMLElement;
      scrollContainer.classList.remove("snap-mandatory", "snap-x");
    }
  }, [pointerPosition.startX, scrollbarProps.left]);

  const handlePointerMove = useCallback((e: PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const scrollContainer = scrollbarRef.current!.parentElement as HTMLElement;
    const containerWidth = scrollbarRef.current!.offsetWidth;
    const { scrollWidth, scrollLeft } = scrollContainer;

    if (pointerPosition.startX !== null) {
      const innerWidth =
        scrollContainer.offsetWidth -
        +getComputedStyle(scrollContainer, null).paddingLeft.replace("px", "") -
        +getComputedStyle(scrollContainer, null).paddingRight.replace("px", "");

      const left = Math.min(
        Math.max(0, (pointerPosition.startLeft ?? 0) + e.clientX - pointerPosition.startX),
        containerWidth - (innerWidth / scrollWidth) * containerWidth
      );

      scrollContainer.scrollTo({
        left: (left / containerWidth) * scrollWidth,
        // @ts-ignore
        behavior: "instant",
      });

      setScrollbarProps({
        width: scrollContainer.offsetWidth / scrollWidth,
        left: (scrollLeft / scrollWidth) * containerWidth,
      });
    }
  }, [pointerPosition]);

  const handlePointerUp = useCallback((e: PointerEvent) => {
    if (pointerPosition.startX !== null) {
      e.preventDefault();
      e.stopPropagation();
      setPointerPosition({ startX: null, startLeft: scrollbarProps.left });
      document.body.classList.remove("[&_*]:!pointer-events-none", "!cursor-grabbing");
      const scrollContainer = scrollbarRef.current!.parentElement as HTMLElement;
      scrollContainer.classList.add("snap-mandatory", "snap-x");
    }
  }, [pointerPosition.startX, scrollbarProps.left]);

  const handleClick = useCallback(async (e) => {
    if (pointerPosition.startX === null) {
      const scrollContainer = scrollbarRef.current!.parentElement as HTMLElement;
      const containerWidth = scrollbarRef.current!.offsetWidth;
      const { scrollWidth } = scrollContainer;
      const thumbWidth = containerWidth / scrollWidth;
      const clickPosition = e.clientX - scrollbarRef.current!.getBoundingClientRect().left;
      const positionPercentage = clickPosition / containerWidth;

      const left = Math.min(
        Math.max(
          0,
          containerWidth * positionPercentage - thumbWidth * containerWidth * positionPercentage
        ),
        containerWidth - (containerWidth / scrollWidth) * containerWidth
      );

      scrollContainer.scrollTo({
        left: (left / containerWidth) * scrollWidth,
        // @ts-ignore
        behavior: "instant",
      });
    }
  }, [pointerPosition.startX]);

  useEffect(() => {
    const scrollContainer = scrollbarRef.current!.parentElement as HTMLElement;

    scrollContainer.addEventListener("scroll", handleScrollEvent);
    return () => {
      scrollContainer.removeEventListener("scroll", handleScrollEvent);
    };
  }, [handleScrollEvent]);

  useEffect(() => {
    handleScrollEvent();
  }, [handleScrollEvent, itemCount]);

  useEffect(() => {
    const scrollContainer = scrollbarRef.current!.parentElement as HTMLElement;
    scrollToX(220, 0, scrollContainer);
  }, [itemCount]);

  useEffect(() => {
    document.addEventListener("pointerup", handlePointerUp);

    return () => {
      document.removeEventListener("pointerup", handlePointerUp);
    };
  }, [handlePointerMove, handlePointerUp]);

  useEffect(() => {
    if (pointerPosition.startX !== null) {
      document.addEventListener("pointermove", handlePointerMove);

      return () => {
        document.removeEventListener("pointermove", handlePointerMove);
      };
    }
    return () => {};
  }, [handlePointerMove, pointerPosition.startX]);

  useEffect(() => {
    const scrollContainer = scrollbarRef.current!.parentElement as HTMLElement;
    if (width) {
      setShowScrollbar(scrollContainer.scrollWidth > scrollContainer.offsetWidth);
    }
  }, [width, itemCount]);

  return (
    <>
      <div
        ref={scrollbarRef}
        aria-hidden
        className={clsx(
          "group absolute top-full flex h-4 cursor-pointer touch-none items-center",
          showCount ? "w-[calc(100%-80px)]" : "w-full"
        )}
        onClick={handleClick}
      >
        <div className="relative h-1 w-full rounded-full bg-gray-200 transition-all group-hover:h-1.5">
          <button
            type="button"
            className="absolute top-1/2 flex min-h-full cursor-grab items-center justify-center py-2 will-change-transform active:cursor-grabbing [&:active_div]:!h-2"
            style={{
              transform: `translateY(-50%) translateX(${scrollbarProps.left}px)`,
              width: `${scrollbarProps.width * 100}%`,
            }}
            onPointerDown={handlePointerDown}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="h-1 w-full rounded-full bg-gray-900 transition-all group-hover:h-1.5" />
          </button>
        </div>
      </div>

      {showCount && itemCount
        ? <div className="absolute top-full right-0 flex flex h-4 w-[86px] items-center justify-end gap-2 font-bold">
            <span>
              {/*{Math.round(1 + scrollbarProps.left * scrollbarProps.width)}{" "}*/}
              {scrollbarRef.current && showScrollbar
                ? Math.round(
                    (scrollbarProps.left /
                      (scrollbarRef.current?.offsetWidth -
                        scrollbarRef.current?.offsetWidth * scrollbarProps.width)) *
                      (itemCount - 1)
                  ) + 1
                : null}{" "}
              <br />
            </span>{" "}
            of <span>{itemCount}</span>
          </div>
        : null}
    </>
  );
};
