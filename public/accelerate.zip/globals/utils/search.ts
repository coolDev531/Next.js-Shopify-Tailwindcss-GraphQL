import create from "zustand/vanilla";
import { debounce, formatMoney, JSONParse, serializeFormWithGroups } from "./utils";
import { _Article_liquid, _Collection_liquid, _Page_liquid, _Product_liquid } from "types/shopify";

export const initSearch = () => {
  initSearchTypesForm();
  initHeaderSearch();
};

function initSearchTypesForm() {
  const searchTypes = document?.querySelector("[data-search-types-form]");

  searchTypes?.addEventListener("submit", (event) => {
    const { type } = serializeFormWithGroups(event.target);
    event.preventDefault();
    const currentHref = window.location.href.replace(/([?&])type=[^&?]*/gi, "");
    window.location.href = currentHref.includes("?")
      ? `${currentHref}&type=${type?.join(",")}`
      : `${currentHref}?type=${type?.join(",")}`;
  });
}

type SearchState = {
  showResults: boolean;
  loading: boolean;
  count: number;
  products: (_Product_liquid & { variants_size?: number })[];
  collections: _Collection_liquid[];
  articles: _Article_liquid[];
  pages: _Page_liquid[];
  types: string[];
  terms: string;
};

const initialSearchState = {
  showResults: false,
  loading: true,
  count: 0,
  products: [],
  collections: [],
  articles: [],
  pages: [],
  types: ["product", "collection", "article", "page"],
  terms: "",
};

export const searchState = create<SearchState>(() => {
  return initialSearchState;
});

const { setState, getState, subscribe } = searchState;

function initHeaderSearch() {
  const searchBar = document?.querySelector<HTMLElement>("[data-header-search-bar]");
  const searchButtons = document?.querySelectorAll<HTMLButtonElement>(
    "[data-header-search-button]"
  );
  const searchInput = document?.querySelector<HTMLInputElement>("[data-header-search-input]");

  const openSearchBar = () => {
    searchBar?.classList.add("active");
    searchInput?.focus();
    setTimeout(
      () => {
        searchInput?.select();
      },
      1
    );
    document.addEventListener("keydown", handleKeyDown);
  };

  const closeSearchBar = () => {
    searchBar?.classList.remove("active");
    document.removeEventListener("keydown", handleKeyDown);
    setState({ showResults: false });
  };

  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Escape") {
      closeSearchBar();
    }
  };

  const toggleSearchBar = () => {
    if (!searchBar.classList.contains("active")) {
      openSearchBar();
    } else {
      closeSearchBar();
    }
  };

  const handleSearchInput = (e) => {
    e.preventDefault();

    setState({ loading: true });
    debounce(
      async (e) => {
        const data = await fetch(
          `${window.Shopify.routes.root}search/suggest?q=${e.target.value}&resources[type]=product,article,page,collection&resources[limit]=5&section_id=predictive-search`
        );
        const content = await data.text();
        const dataElement = document.createElement("div");
        dataElement.innerHTML = content;
        const searchData = JSONParse<SearchState>(dataElement?.querySelector("script")?.innerHTML);
        if (searchData) {
          setState({ ...searchData, showResults: true, loading: false });
        }
      },
      400
    )(e);
  };
  searchButtons.forEach((button) => button.addEventListener("click", toggleSearchBar));

  searchInput.addEventListener("input", handleSearchInput);
}

const searchDisplay = document?.querySelector<HTMLElement>("[data-search-display]");

type SearchSettings = {
  show: boolean;
  vendor__show: boolean;
  rating__show: boolean;
  labels__show: boolean;
  labels__discount: "sale" | "percentage" | "value";
  image__ratio: string;
  image__show_secondary: boolean;
  image__background: string;
  image__drop_shadow: boolean;
  search_count: number;
  columns__desktop: string;
  columns__mobile: string;
  article_show_date: boolean;
  article_show_author: boolean;
};

const searchDisplaySettings = JSONParse<SearchSettings>(
  document?.querySelector<HTMLElement>("[data-search-display-settings]")?.innerHTML
);

const searchDisplayGrid = searchDisplay?.querySelector<HTMLElement>("[data-search-display-grid]");

const productPlaceholder = searchDisplayGrid
  ?.querySelector("[data-search-display-product]")
  ?.cloneNode(true) as HTMLElement;

const contentPlaceholder = searchDisplayGrid
  ?.querySelector("[data-search-display-content]")
  ?.cloneNode(true) as HTMLElement;

const loadingElement = searchDisplay?.querySelector<HTMLElement>("[data-search-display-loading]");

const emptyResultsElement = searchDisplay?.querySelector<HTMLElement>(
  "[data-search-display-empty]"
);

searchDisplayGrid.innerHTML = "";

subscribe((state) => {
  if (state.showResults && !state.loading) {
    searchDisplay.classList.remove("hidden");
    loadingElement.classList.add("hidden");
    searchDisplayGrid.innerHTML = "";

    const content = {
      image: contentPlaceholder?.querySelector("[data-card-image]"),
      title: contentPlaceholder?.querySelector("[data-card-title]"),
      date: contentPlaceholder?.querySelector("[data-card-date]"),
      ctaLink: contentPlaceholder?.querySelector("[data-card-cta-link]"),
      ctaContent: contentPlaceholder?.querySelector("[data-card-cta-content]"),
    };

    const { products, collections, articles, pages } = state;
    products.forEach((productData) => {
      const productClone = productPlaceholder?.cloneNode(true) as HTMLElement;

      productClone.setAttribute("data-drawer-product", productData.id.toString());
      productClone.setAttribute("data-drawer-product-url", productData.url.split("?")[0]);

      const product = {
        imageLink: productClone?.querySelector<HTMLAnchorElement>("[data-card-image-link]"),
        image: productClone?.querySelector<HTMLImageElement>("[data-card-image] img"),
        secondaryImage: productClone?.querySelector<HTMLElement>("[data-card-secondary-image]"),
        secondaryImageEl: productClone?.querySelector<HTMLImageElement>(
          "[data-card-secondary-image] img"
        ),
        variantCount: productClone?.querySelector<HTMLElement>("[data-card-variant-count]"),
        labelContainer: productClone?.querySelector<HTMLElement>("[data-card-label-container]"),
        label: productClone
          ?.querySelector("[data-card-label-placeholder]")
          .cloneNode(true) as HTMLSpanElement,
        labelDiscount: productClone
          ?.querySelector("[data-card-label-discount]")
          .cloneNode(true) as HTMLSpanElement,
        labelSoldOut: productClone
          ?.querySelector("[data-card-label-sold-out]")
          .cloneNode(true) as HTMLSpanElement,
        title: productClone?.querySelector<HTMLAnchorElement>("[data-card-title]"),
        priceFromRegular: productClone?.querySelector<HTMLElement>(
          "[data-product-price-from-regular]"
        ),
        priceFromCompare: productClone?.querySelector<HTMLElement>(
          "[data-product-price-from-compare]"
        ),
        priceRegular: productClone?.querySelector<HTMLElement>("[data-product-price-regular]"),
        priceCompare: productClone?.querySelector<HTMLElement>("[data-product-price-compare]"),
        reviews: productClone.querySelector<HTMLElement>("[data-card-reviews]"),
        ratingStars: productClone.querySelectorAll<SVGStopElement>("[data-star-rating]"),
        ratingText: productClone.querySelector<HTMLElement>("[data-card-reviews-text]"),
        vendor: productClone?.querySelector<HTMLElement>("[data-card-vendor]"),
        ctaLink: productClone?.querySelector<HTMLAnchorElement>("[data-card-cta-link]"),
        ctaContent: productClone?.querySelectorAll<HTMLSpanElement>("[data-card-cta-content]"),
        ctaSoldOut: productClone?.querySelectorAll<HTMLSpanElement>("[data-card-cta-sold-out]"),
        ctaButton: productClone?.querySelector<HTMLButtonElement>("[data-card-cta-button]"),
      };

      product.labelContainer.innerHTML = "";

      if (product.vendor) {
        product.vendor.innerHTML = productData.vendor || "";
      }

      product.ctaLink.href = productData.url;

      product.ctaButton.setAttribute(`data-product-drawer-add-button`, productData.id.toString());

      if (productData.available) {
        product.ctaContent.forEach((element) => {
          element.classList.remove("hidden");
        });
        product.ctaSoldOut.forEach((element) => {
          element.classList.add("hidden");
        });
      }
      if (!productData.available) {
        product.ctaContent.forEach((element) => {
          element.classList.add("hidden");
        });
        product.ctaSoldOut.forEach((element) => {
          element.classList.remove("hidden");
        });
      }

      if (
        product.reviews &&
        productData.metafields.reviews &&
        "rating" in productData.metafields.reviews && // @ts-ignore
        "rating" in productData.metafields.reviews.rating &&
        "rating_count" in productData.metafields.reviews
      ) {
        product.reviews.classList.remove("hidden");
        const ratingCount = productData.metafields?.reviews?.rating_count ?? 0;
        const rating = +productData.metafields?.reviews?.rating?.rating;
        product.ratingStars.forEach((star) => {
          const starIndex = +star.dataset.starRating + 1;
          star.setAttribute(
            "offset",
            starIndex <= Math.floor(rating)
              ? "100%"
              : starIndex >= Math.floor(rating) && starIndex <= Math.ceil(rating)
              ? `${(rating - Math.floor(rating)) * 100}%`
              : "0%"
          );
        });
        product.ratingText.innerHTML = ratingCount
          ? ratingCount > 1
            ? `${ratingCount} reviews`
            : `${ratingCount} review`
          : `No reviews`;
      }

      product.title.innerHTML = productData.title;
      product.title.href = productData.url;

      product.priceRegular = formatMoney(productData.price);
      product.priceFromRegular.classList.add("hidden");
      product.priceFromCompare.classList.add("hidden");
      product.priceCompare.classList.add("hidden");
      if ((productData.compare_at_price ?? 0) > productData.price) {
        product.priceCompare.classList.remove("hidden");
        product.priceCompare.innerHTML = formatMoney(productData.price);
      }

      if (productData.compare_at_price_varies) {
        product.priceFromCompare.classList.remove("hidden");
      } else if (productData.price_varies) {
        product.priceFromRegular.classList.remove("hidden");
      }

      if (!productData.available) {
        product.labelSoldOut.classList.remove("hidden");
        product.labelContainer.append(product.labelSoldOut);
      }

      if ((productData.compare_at_price ?? 0) > productData.price) {
        product.labelDiscount.classList.remove("hidden");
        switch (searchDisplaySettings?.labels__discount) {
          case "sale": {
            product.labelDiscount.innerHTML = "On Sale";
            break;
          }
          case "value": {
            const savings = productData.compare_at_price - productData.price;
            product.labelDiscount.innerHTML = `Save ${formatMoney(savings)}`;
            break;
          }
          case "percentage": {
            const savingsPercentage = Math.round(
              ((productData.compare_at_price - productData.price) / productData.compare_at_price) *
                100
            );
            product.labelDiscount.innerHTML = `${savingsPercentage}% off`;
            break;
          }
        }
        product.labelContainer.append(product.labelDiscount);
      }

      if (
        "product_labels" in productData.metafields.accelerate &&
        Array.isArray(productData.metafields.accelerate.product_labels)
      ) {
        productData.metafields.accelerate.product_labels.forEach((label) => {
          const labelClone = product.label.cloneNode(true) as HTMLSpanElement;
          labelClone.classList.remove("hidden");
          labelClone.innerHTML = label;
          product.labelContainer.append(labelClone);
        });
      }

      product.variantCount?.classList.add("hidden");
      if (product.variantCount && productData.variants_size > 1) {
        product.variantCount.innerHTML = `Available in ${productData.variants_size} variations`;
        product.variantCount?.classList.remove("hidden");
      }

      product.imageLink.href = productData.url;
      product.image.src = `${productData.images?.[0]}?width=360`;
      product.secondaryImage?.classList?.add("hidden");
      product.image.classList.add("hidden");

      if (productData.images[1] && product.secondaryImage) {
        product.secondaryImageEl.src = `${productData.images[1]}?width=360`;
        product.secondaryImage.classList.remove("hidden");
      }

      if (productData.images?.[0]) {
        product.image.classList.remove("hidden");
        product.image.onload = () => {
          searchDisplayGrid.append(productClone);
        };
      } else {
        searchDisplayGrid.append(productClone);
      }

      // loadProduct(productClone);
    });
  }
  if (state.loading) {
    loadingElement.classList.remove("hidden");
    console.log("loading spinner");
  }
  if (!state.showResults) {
    searchDisplay.classList.add("hidden");
  }
});
