import { FC, HTMLAttributes } from "react";

const getSrcSet = (src, screenPercentage, maxWidth): string => {
  if (src.includes("?")) {
    return [48, 96, 256, 384, 460, 640, 1200, 1920, 3840]
      .map((number) => {
        if (maxWidth && number > maxWidth) {
          return null;
        }
        return `${src}&width=${Math.round((number / 100) * screenPercentage)} ${number}w`;
      })
      .filter((d) => !!d)
      .join(",");
  }
  return [48, 96, 256, 384, 460, 640, 1200, 1920, 3840]
    .map((number) => {
      if (maxWidth && number > maxWidth) {
        return null;
      }
      return `${src}?width=${Math.round((number / 100) * screenPercentage)} ${number}w`;
    })
    .filter((d) => !!d)
    .join(",");
};

export const Image: FC<
  {
    className?: string;
    src: string;
    alt?: string;
    srcSet?: string;
    width?: number;
    height?: number;
    maxWidth?: 48 | 96 | 256 | 384 | 460 | 640 | 1200 | 1920 | 3840;
    aspectRatio?: number;
    screenPercentage?: number;
  } & Partial<HTMLAttributes<HTMLImageElement>>
> = ({
  src,
  alt,
  className,
  width,
  height,
  aspectRatio,
  screenPercentage = 100,
  maxWidth,
  srcSet,
  ...imageProps
}) => {
  if (!src) {
    return null;
  }

  return (
    // @ts-ignore
    <img
      src={
        width
          ? src.includes("?")
            ? `${src}&width=${width}`
            : `${src}?width=${width}`
          : maxWidth
          ? src.includes("?")
            ? `${src}&width=${maxWidth}`
            : `${src}?width=${maxWidth}`
          : src
      }
      alt={alt}
      width={width}
      height={height}
      className={className}
      srcSet={getSrcSet(src, screenPercentage, maxWidth)}
      {...imageProps}
    />
  );
};
