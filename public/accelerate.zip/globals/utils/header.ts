import { delay, trapFocus } from "globals/utils/utils";

export const initHeaderMenu = () => {
  const header = document.querySelector(`[data-section="header"]:not([data-initiated])`);
  if (header) {
    header.setAttribute("data-initiated", "");
    initDesktopNav();
    initMobileNav();
  }

  initShopifyEvents();
};

function initMobileNav() {
  const mobileNav = document.querySelector<HTMLElement>("[data-mobile-nav]");
  const menuLinklist = document.querySelectorAll<HTMLElement>("[data-mobile-menu-dropdown]");
  const menuLinks = document.querySelectorAll<HTMLAnchorElement>("[data-mobile-menu-link]");
  const menuBackButton = document.querySelectorAll<HTMLAnchorElement>("[data-mobile-menu-back]");

  document.addEventListener("nav:closed", () => {
    menuLinklist.forEach((linklist) => {
      const dropdownLevel = +linklist.dataset.mobileMenuLevel;
      linklist.classList.remove("-translate-x-full", "opacity-0");
      if (dropdownLevel > 1) {
        linklist.classList.add("translate-x-full", "opacity-0");
      }
    });
  });

  const handleMenuLinkClick = (e) => {
    const handle = e.currentTarget.dataset.mobileMenuLink;
    const currentHandle = e.currentTarget.dataset.mobileMenuCurrentDropdown;
    const currentDropdown = mobileNav.querySelector(
      `[data-mobile-menu-dropdown="${currentHandle}"]`
    );
    const dropdown = mobileNav.querySelector(`[data-mobile-menu-dropdown="${handle}"]`);

    if (!dropdown) {
      document.dispatchEvent(new Event("nav:close"));
      return;
    }
    currentDropdown.classList.add("-translate-x-full", "opacity-0");
    dropdown.classList.remove("translate-x-full", "opacity-0");
    e.preventDefault();
  };

  const handleMenuBackClick = (e) => {
    const prevHandle = e.currentTarget.dataset.mobileMenuPrevDropdown;
    const currentHandle = e.currentTarget.dataset.mobileMenuBack;
    const prevMenu = mobileNav.querySelector(`[data-mobile-menu-dropdown="${prevHandle}"]`);
    const currentMenu = mobileNav.querySelector(`[data-mobile-menu-dropdown="${currentHandle}"]`);

    currentMenu.classList.add("translate-x-full", "opacity-0");
    prevMenu.classList.remove("-translate-x-full", "opacity-0");
    e.preventDefault();
  };

  menuLinks.forEach((link) => {
    link.addEventListener("click", handleMenuLinkClick);
  });

  menuBackButton.forEach((link) => {
    link.addEventListener("click", handleMenuBackClick);
  });

  document.addEventListener("shopify:block:select", (e) => {
    const megaMenu = e.target as HTMLElement;
    const handle = megaMenu.dataset.mobileMenuDropdown;

    if (handle) {
      const link = document.querySelector<HTMLElement>(`[data-header-link="${handle}"]`);
      if (!link) {
        megaMenu.classList.remove("translate-x-full", "opacity-0");
        document.dispatchEvent(new Event("nav:open"));
        console.log("mobile nav based!");
        return;
      }
    }
  });

  document.addEventListener("shopify:block:deselect", (e) => {
    const megaMenu = e.target as HTMLElement;
    const handle = megaMenu.dataset.mobileMenuDropdown;
    if (handle) {
      const link = document.querySelector<HTMLElement>(`[data-header-link="${handle}"]`);
      if (!link) {
        document.dispatchEvent(new Event("nav:open"));
        console.log("mobile nav based!");
        return;
      }
    }
  });
}

function initDesktopNav() {
  const primaryLinks = document.querySelectorAll<HTMLElement>("[data-header-link]");

  primaryLinks.forEach((link) => {
    initMenuLink(link);
  });

  function initMenuLink(link: HTMLElement) {
    const handle: string = link.dataset.headerLink;
    const dropdownMenu = document.querySelector<HTMLElement>(
      `[data-header-link-dropdown="${handle}"]`
    );
    const megaMenu = document.querySelector<HTMLElement>(`[data-header-link-megamenu="${handle}"]`);

    if (dropdownMenu && !megaMenu) {
      initDropdownMenu({ link, dropdownMenu });
    }
    if (megaMenu) {
      initMegamenu({ link, megaMenu });
    }
  }

  function initDropdownMenu({
    link,
    dropdownMenu,
  }: {
    dropdownMenu: HTMLElement;
    link: HTMLElement;
  }) {
    let menuOpen = false;
    let menuCloseTimeout: NodeJS.Timeout = null;

    const handleExit = (e) => {
      clearTimeout(menuCloseTimeout);
      menuCloseTimeout = setTimeout(
        () => {
          menuOpen = false;
          link.removeEventListener("mouseleave", handleExit);

          link.classList.remove("active");
          dropdownMenu.style.opacity = "0";
          dropdownMenu.style.pointerEvents = "none";

          dropdownMenu.removeEventListener("mouseover", handleHover);
          dropdownMenu.removeEventListener("mouseleave", handleExit);
        },
        50
      );
    };

    const handleHover = async (e) => {
      clearTimeout(menuCloseTimeout);
      await delay(2);
      if (!menuOpen) {
        menuOpen = true;
        e.preventDefault();
        e.stopPropagation();

        link.classList.add("active");
        dropdownMenu.style.left = `${link.getBoundingClientRect().left}px`;
        dropdownMenu.style.opacity = "1";
        dropdownMenu.style.pointerEvents = "auto";

        link.addEventListener("mouseleave", handleExit);
        dropdownMenu.addEventListener("mouseover", handleHover);
        dropdownMenu.addEventListener("mouseleave", handleExit);
      }
    };

    link.addEventListener("mouseover", handleHover);

    const handleDocumentClick = (e) => {
      if (!menuOpen) {
        document.removeEventListener("click", handleDocumentClick, true);
        dropdownMenu.style.opacity = "0";
        dropdownMenu.style.pointerEvents = "none";
      }

      const outsideClick = !link.contains(e.target) && !dropdownMenu.contains(e.target);

      if (outsideClick) {
        e.preventDefault();
        e.stopPropagation();
        menuOpen = false;
        document.removeEventListener("click", handleDocumentClick, true);
        dropdownMenu.style.opacity = "0";
        dropdownMenu.style.pointerEvents = "none";
      }
    };

    const handleClick = (e) => {
      if (!menuOpen && e.pointerType === "touch") {
        e.stopPropagation();
        e.preventDefault();
        menuOpen = true;
        link.classList.add("active");
        dropdownMenu.style.left = `${link.getBoundingClientRect().left}px`;
        dropdownMenu.style.opacity = "1";
        dropdownMenu.style.pointerEvents = "auto";
        document.addEventListener("click", handleDocumentClick, true);
      }
    };

    link.addEventListener("click", handleClick, true);
  }

  function initMegamenu({ link, megaMenu }: { link: HTMLElement; megaMenu: HTMLElement }) {
    let menuOpen = false;
    let menuCloseTimeout: NodeJS.Timeout = null;
    let forceMenuOpen = false;

    const handleExit = (e) => {
      clearTimeout(menuCloseTimeout);
      menuCloseTimeout = setTimeout(
        () => {
          menuOpen = false;

          link.classList.remove("active");
          megaMenu.style.opacity = "0";
          megaMenu.style.pointerEvents = "none";

          link.removeEventListener("mouseleave", handleExit);
          megaMenu.removeEventListener("mouseover", handleHover);
          megaMenu.removeEventListener("mouseleave", handleExit);
        },
        50
      );
    };

    const handleHover = async (e) => {
      clearTimeout(menuCloseTimeout);
      await delay(2);
      if (forceMenuOpen) return;
      if (!menuOpen) {
        menuOpen = true;
        e.preventDefault();
        e.stopPropagation();

        link.classList.add("active");
        megaMenu.style.opacity = "1";
        megaMenu.style.pointerEvents = "auto";

        link.addEventListener("mouseleave", handleExit);
        megaMenu.addEventListener("mouseover", handleHover);
        megaMenu.addEventListener("mouseleave", handleExit);
      }
    };

    link.addEventListener("mouseover", handleHover);

    const handleDocumentClick = (e) => {
      if (forceMenuOpen) return;
      if (!menuOpen) {
        document.removeEventListener("click", handleDocumentClick, true);
        megaMenu.style.opacity = "0";
        megaMenu.style.pointerEvents = "none";
      }

      const outsideClick = !link.contains(e.target) && !megaMenu.contains(e.target);

      if (outsideClick) {
        e.preventDefault();
        e.stopPropagation();
        menuOpen = false;
        document.removeEventListener("click", handleDocumentClick, true);
        megaMenu.style.opacity = "0";
        megaMenu.style.pointerEvents = "none";
      }
    };

    const handleClick = (e) => {
      if (forceMenuOpen) return;
      if (!menuOpen && e.pointerType === "touch") {
        e.stopPropagation();
        e.preventDefault();
        menuOpen = true;
        link.classList.add("active");
        megaMenu.style.opacity = "1";
        megaMenu.style.pointerEvents = "auto";
        document.addEventListener("click", handleDocumentClick, true);
      }
    };

    link.addEventListener("click", handleClick, true);

    document.addEventListener("shopify:block:select", (e) => {
      const megaMenu = e.target as HTMLElement;
      const handle = megaMenu.dataset.headerLinkMegamenu;
      console.log({ handle });
      if (handle) {
        const link = document.querySelector<HTMLElement>(`[data-header-link="${handle}"]`);
        if (!link) {
          console.log("mobile nav based!");
          return;
        }
        link.classList.add("active");
        megaMenu.style.opacity = "1";
        megaMenu.style.pointerEvents = "auto";
        forceMenuOpen = true;
      }
    });

    document.addEventListener("shopify:block:deselect", (e) => {
      const megaMenu = e.target as HTMLElement;
      const handle = megaMenu.dataset.headerLinkMegamenu;
      if (handle) {
        const link = document.querySelector<HTMLElement>(`[data-header-link="${handle}"]`);
        if (!link) {
          console.log("mobile nav based!");
          return;
        }
        link.classList.remove("active");
        megaMenu.style.opacity = "0";
        megaMenu.style.pointerEvents = "none";
        forceMenuOpen = false;
      }
    });
  }
}

function initShopifyEvents() {
  document.addEventListener("shopify:section:load", (e) => {
    const element = e.target as HTMLElement;
    const { type, disabled } = JSON.parse(element.dataset.shopifyEditorSection);

    if (type === "header" && !disabled) {
      initDesktopNav();
      initMobileNav();
    }
  });

  document.addEventListener("shopify:section:select", (e) => {
    const element = e.target as HTMLElement;
    const { type, disabled } = JSON.parse(element.dataset.shopifyEditorSection);

    if (type === "header-megamenu" && !disabled) {
      const megaMenu = element.querySelector<HTMLElement>(`[data-header-link-megamenu]`);
      const handle = megaMenu.dataset.headerLinkMegamenu;
      const link = document.querySelector<HTMLElement>(`[data-header-link="${handle}"]`);
      link.classList.add("active");
      megaMenu.style.opacity = "1";
      megaMenu.style.pointerEvents = "auto";
    }
  });

  document.addEventListener("shopify:section:deselect", (e) => {
    const element = e.target as HTMLElement;
    const { type, disabled } = JSON.parse(element.dataset.shopifyEditorSection);

    if (type === "header-megamenu" && !disabled) {
      const megaMenu = element.querySelector<HTMLElement>(`[data-header-link-megamenu]`);
      const handle = megaMenu.dataset.headerLinkMegamenu;
      const link = document.querySelector<HTMLElement>(`[data-header-link="${handle}"]`);
      link.classList.remove("active");
      megaMenu.style.opacity = "0";
      megaMenu.style.pointerEvents = "none";
    }
  });
}
