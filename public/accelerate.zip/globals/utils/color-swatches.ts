import { JSONParse, toKebabCase } from "globals/utils/utils";

export const initColorSwatches = () => {
  const colors = JSONParse(
    document.querySelector<HTMLScriptElement>("[data-color-swatches]")?.innerHTML
  );

  const swatchStyles = document.createElement("style");
  swatchStyles.innerHTML = `

  :root {
  ${Object.entries(colors)
    .map(([key, value]) => {
      const variable = toKebabCase(key);
      const color = value.replace(/.([^?.]+)\)$/gi, ".$1?width=32&height=32&crop=center)");
      return `  --color-swatch--${variable}: ${color};`;
    })
    .join("\n")}
  }`;

  document.head.append(swatchStyles);
};
