import clsx from "clsx";
import { useGlobalSettings } from "globals/utils/global-stores";
import { FC, HTMLAttributes, PropsWithChildren } from "react";

export type TypeOptions =
  | 1
  | "h1"
  | 2
  | "h2"
  | 3
  | "h3"
  | 4
  | "h4"
  | 5
  | "h5"
  | 6
  | "h6"
  | 7
  | "body"
  | "prose";

export const Typography: FC<
  PropsWithChildren<
    {
      fontType: TypeOptions;
      className?: string;
    } & HTMLAttributes<HTMLElement>
  >
> = ({ fontType, children, className, ...props }) => {
  const settings = useGlobalSettings();
  let tag: typeof settings.font_body_tag = "div";
  let baseClass = "body";

  switch (fontType) {
    case 1:
      tag = settings.font_heading_1_tag;
      baseClass = "h1";
      break;
    case "h1":
      tag = settings.font_heading_1_tag;
      baseClass = "h1";
      break;
    case 2:
      tag = settings.font_heading_2_tag;
      baseClass = "h2";
      break;
    case "h2":
      tag = settings.font_heading_2_tag;
      baseClass = "h2";
      break;
    case 3:
      tag = settings.font_heading_3_tag;
      baseClass = "h3";
      break;
    case "h3":
      tag = settings.font_heading_3_tag;
      baseClass = "h3";
      break;
    case 4:
      tag = settings.font_heading_4_tag;
      baseClass = "h4";
      break;
    case "h4":
      tag = settings.font_heading_4_tag;
      baseClass = "h4";
      break;
    case 5:
      tag = settings.font_heading_5_tag;
      baseClass = "h5";
      break;
    case "h5":
      tag = settings.font_heading_5_tag;
      baseClass = "h5";
      break;
    case 6:
      tag = settings.font_heading_6_tag;
      baseClass = "h6";
      break;
    case "h6":
      tag = settings.font_heading_6_tag;
      baseClass = "h6";
      break;
    case 7:
      tag = settings.font_body_tag;
      baseClass = "p";
      break;
    case "body":
      tag = settings.font_body_tag;
      baseClass = "p";
      break;
    case "prose":
      tag = "div";
      baseClass = "prose prose-theme p";
  }

  switch (tag) {
    case "p":
      return (
        <p className={clsx(baseClass, className)} {...props}>
          {children}
        </p>
      );
    case "h1":
      return (
        <h1 className={clsx(baseClass, className)} {...props}>
          {children}
        </h1>
      );
    case "h2":
      return (
        <h2 className={clsx(baseClass, className)} {...props}>
          {children}
        </h2>
      );
    case "h3":
      return (
        <h3 className={clsx(baseClass, className)} {...props}>
          {children}
        </h3>
      );
    case "h4":
      return (
        <h4 className={clsx(baseClass, className)} {...props}>
          {children}
        </h4>
      );
    case "h5":
      return (
        <h5 className={clsx(baseClass, className)} {...props}>
          {children}
        </h5>
      );
    case "h6":
      return (
        <h6 className={clsx(baseClass, className)} {...props}>
          {children}
        </h6>
      );
    case "blockquote":
      return (
        <blockquote className={clsx(baseClass, className)} {...props}>
          {children}
        </blockquote>
      );
    case "div":
      return (
        <div className={clsx(baseClass, className)} {...props}>
          {children}
        </div>
      );
  }
};
