import { CustomLiquidSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const customLiquid: ShopifySection<CustomLiquidSection> = {
  name: "Custom Liquid",
  settings: [
    {
      type: "liquid",
      id: "custom_liquid",
      label: "Custom Liquid",
      info: "Add app snippets or other Liquid code to create advanced customizations.",
    },
  ],
  presets: [
    {
      name: "Custom Liquid",
    },
  ],
};
