import { productBlocks } from "globals/settings/product-blocks";
import { sectionGlobals } from "globals/settings/section-globals";
import { ShopifySection } from "types/shopify";
import { CustomProductAndrewsSection } from "types/sections";

export const customProductAndrews: ShopifySection<CustomProductAndrewsSection> = {
  name: "Custom Product Andrews",
  generate_block_files: ["description_tabs"],
  settings: [
    {
      type: "checkbox",
      id: "sticky",
      default: true,
      label: "Enable sticky content on desktop",
    },
    {
      type: "checkbox",
      id: "breadcrumbs__show",
      label: "Show breadcrumbs",
      default: true,
    },
    {
      type: "header",
      content: "Media Gallery",
      info: "Learn more about [media types.](https://help.shopify.com/manual/products/product-media)",
    },
    {
      type: "radio",
      id: "gallery__layout",
      label: "Layout",
      default: "horizontal",
      options: [
        {
          value: "horizontal",
          label: "Horizontal Slider",
        },
        {
          value: "vertical",
          label: "Vertical Scroll",
        },
        {
          value: "grid",
          label: "Grid",
        },
      ],
    },
    {
      type: "checkbox",
      id: "gallery__show_thumbnails",
      label: "Show Thumbnails",
      default: false,
    },
    {
      type: "radio",
      id: "gallery__size",
      options: [
        {
          value: "small",
          label: "Small",
        },
        {
          value: "medium",
          label: "Medium",
        },
        {
          value: "large",
          label: "Large",
        },
      ],
      default: "large",
      label: "Desktop media size",
      info: "Media is automatically optimized for mobile.",
    },
    {
      type: "checkbox",
      id: "gallery__loop_videos",
      default: false,
      label: "Enable video looping",
    },
    sectionGlobals.sectionLayout,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    productBlocks.app,
    productBlocks.text,
    productBlocks.title,
    productBlocks.vendor,
    productBlocks.price,
    productBlocks.variant_selector,
    productBlocks.sku,
    productBlocks.quantity_selector,
    productBlocks.buy_buttons,
    productBlocks.dynamic_buy_buttons,
    productBlocks.description,
    {
      type: "description_tabs" as const,
      name: "Description Tabs",
      limit: 1,
      settings: [
        {
          type: "header",
          content: "Tab 1",
        },
        {
          type: "text",
          id: "tab_title_1",
          label: "Title",
        },
        {
          type: "text",
          id: "match_from_1",
          label: "Match Opening",
        },
        {
          type: "text",
          id: "match_to_1",
          label: "Match Closing",
        },
        {
          type: "header",
          content: "Tab 2",
        },
        {
          type: "text",
          id: "tab_title_2",
          label: "Title",
        },
        {
          type: "text",
          id: "match_from_2",
          label: "Match Opening",
        },
        {
          type: "text",
          id: "match_to_2",
          label: "Match Closing",
        },
        {
          type: "header",
          content: "Tab 3",
        },
        {
          type: "text",
          id: "tab_title_3",
          label: "Title",
        },
        {
          type: "text",
          id: "match_from_3",
          label: "Match Opening",
        },
        {
          type: "text",
          id: "match_to_3",
          label: "Match Closing",
        },
      ],
    },
    productBlocks.share,
    productBlocks.custom_liquid,
    productBlocks.collapsible_tab,
    productBlocks.rating,
    productBlocks.complementary,
    productBlocks.icon_with_text,
    productBlocks.inventory,
    productBlocks.image,
    productBlocks.pre_order,
    productBlocks.product_sibling,
  ],
};
