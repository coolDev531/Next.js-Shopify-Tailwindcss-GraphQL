import { sectionGlobals } from "globals/settings/section-globals";
import { productBlocks } from "globals/settings/product-blocks";
import { ProductDrawerSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const productDrawer: ShopifySection<ProductDrawerSection> = {
  name: "Product drawer",
  disabled_block_files: true,
  settings: [
    {
      type: "checkbox",
      id: "active",
      label: "Enable Product Drawer",
      default: true,
    },
    sectionGlobals.colorScheme,
  ],
  blocks: [
    productBlocks.image,
    productBlocks.text,
    productBlocks.title,
    productBlocks.vendor,
    productBlocks.price,
    productBlocks.variant_selector,
    productBlocks.sku,
    productBlocks.quantity_selector,
    productBlocks.buy_buttons,
    productBlocks.dynamic_buy_buttons,
    productBlocks.description,
    productBlocks.share,
    productBlocks.custom_liquid,
    productBlocks.collapsible_tab,
    productBlocks.rating,
    productBlocks.complementary,
    productBlocks.icon_with_text,
    productBlocks.inventory,
  ],
};
