import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { FeaturedCollectionGridSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const featuredCollectionGrid: ShopifySection<FeaturedCollectionGridSection> = {
  name: "Featured collection grid",
  settings: [
    {
      type: "product_list",
      id: "products",
      label: "Products",
    },
    {
      type: "collection",
      id: "collection",
      label: "Collection",
    },
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  max_blocks: 1,
  blocks: [
    {
      type: "image",
      name: "Image",
      settings: [
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
        },
        sectionGlobals.colorScheme,
      ],
    },
    {
      type: "content",
      name: "Content",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "Content",
        },
        {
          type: "text",
          id: "preheading",
          label: "Pre heading",
        },
        typeRange({ id: "preheading_font", label: "Pre heading style", default_font: 3 }),
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        typeRange({ id: "title_font", label: "Title style", default_font: 1 }),
        {
          type: "textarea",
          id: "subtitle",
          label: "Subtitle",
        },
        typeRange({ id: "subtitle_font", label: "Subtitle style", default_font: 2 }),
        {
          type: "richtext",
          id: "content",
          label: "Richtext",
        },
        {
          type: "text",
          id: "button_primary__text",
          label: "Primary Button",
        },
        {
          type: "url",
          id: "button_primary__url",
          label: "Primary Button Link",
        },
        {
          type: "text",
          id: "button_secondary__text",
          label: "Secondary Button",
        },
        {
          type: "url",
          id: "button_secondary__url",
          label: "Secondary Button Link",
        },
        {
          type: "header",
          content: "Layout",
        },
        {
          type: "radio",
          id: "align__vertical",
          label: "Vertical Alignment",
          default: "justify-center",
          options: [
            {
              value: "justify-start",
              label: "Top",
            },
            {
              value: "justify-center",
              label: "Center",
            },
            {
              value: "justify-end",
              label: "Bottom",
            },
          ],
        },
        {
          type: "radio",
          id: "align__horizontal",
          label: "Horizontal Alignment",
          default: "items-center text-center",
          options: [
            {
              value: "items-start text-left",
              label: "Left",
            },
            {
              value: "items-center text-center",
              label: "Center",
            },
            {
              value: "items-end text-right",
              label: "Right",
            },
          ],
        },
        sectionGlobals.colorScheme,
      ],
    },
  ],
  presets: [
    {
      name: "Featured collection grid",
    },
  ],
};
