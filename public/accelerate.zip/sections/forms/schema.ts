import { colSpacing } from "globals/settings/col-spacing";
import { sectionGlobals } from "globals/settings/section-globals";
import { inputAutocomplete } from "globals/settings/input-autocomplete";
import { maxWidth } from "globals/settings/max-width";
import { FormsSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const forms: ShopifySection<FormsSection> = {
  name: "Forms",
  disabled_block_files: true,
  settings: [
    {
      type: "select",
      id: "type",
      label: "Type",
      default: "customer_login",
      options: [
        {
          value: "customer",
          label: "Newsletter",
        },
        {
          value: "customer_login",
          label: "Sign In",
        },
        {
          value: "create_customer",
          label: "Sign Up",
        },
        {
          value: "customer_address",
          label: "Address Change",
        },
        {
          value: "contact",
          label: "Contact",
        },
        {
          value: "reset_customer_password",
          label: "Password Reset",
        },
        {
          value: "recover_customer_password",
          label: "Password Recover",
        },
        {
          value: "activate_customer_password",
          label: "Password Activate",
        },
      ],
    },
    {
      type: "checkbox",
      id: "hide_if_account",
      label: "Hide Section if already signed-in",
      default: true,
    },
    {
      type: "checkbox",
      id: "show_only_on_target",
      label: "Show only on target",
      default: false,
    },
    {
      type: "text",
      id: "target_id",
      label: "Target Id",
    },
    {
      type: "textarea",
      id: "success_message",
      label: "Success message",
      info: "Replaces all form fields on successful submission",
      default: "Thank you for contacting us.",
    },
    {
      type: "select",
      id: "redirect",
      label: "Redirect after submission",
      default: "off",
      options: [
        {
          value: "off",
          label: "Off",
        },
        {
          value: "/",
          label: "home",
        },
        {
          value: "/account",
          label: "Account (User must be logged in)",
        },
        {
          value: "/account/login",
          label: "Sign In",
        },
        {
          value: "/account/login#recover",
          label: "Password Recovery",
        },
        {
          value: "/account/register",
          label: "Sign Up",
        },
        {
          value: "/account/logout",
          label: "Sign Out (User must be logged in)",
        },
        {
          value: "/account/addresses",
          label: "Customer Addresses",
        },
        {
          value: "/cart",
          label: "Cart",
        },
      ],
    },
    maxWidth,
    {
      type: "header",
      content: "Image",
    },
    {
      type: "checkbox",
      id: "fullwidth",
      label: "Full-width",
      default: false,
    },
    {
      type: "image_picker",
      id: "image",
      label: "Image",
    },
    {
      type: "color_background",
      id: "image__overlay",
      label: "Overlay",
      default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
    },
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "text",
      name: "Text",
      settings: [
        {
          type: "richtext",
          id: "title",
          label: "Content",
        },
        {
          type: "radio",
          id: "style",
          label: "Heading Style",
          default: "h2",
          options: [
            {
              value: "h1",
              label: "h1",
            },
            {
              value: "h2",
              label: "h2",
            },
            {
              value: "h3",
              label: "h3",
            },
            {
              value: "h4",
              label: "h4",
            },
            {
              value: "preheading",
              label: "pre-header",
            },
            {
              value: "richtext",
              label: "richtext",
            },
          ],
        },
        colSpacing,
      ],
    },
    {
      type: "separator",
      name: "Separator",
      settings: [
        {
          type: "range",
          id: "height",
          label: "Height",
          default: 30,
          min: 2,
          max: 128,
          step: 2,
          unit: "px",
        },
      ],
    },
    {
      type: "password",
      name: "Password",
      limit: 1,
      settings: [
        {
          type: "header",
          content: "Password Input",
        },
        {
          type: "text",
          id: "title",
          label: "Label",
          default: "Password",
        },
        {
          type: "header",
          content: "Confirm Password Input",
        },
        {
          type: "paragraph",
          content: "Only on required Form Types",
        },
        {
          type: "text",
          id: "confirm_pw__title",
          label: "Label",
          default: "Confirm Password",
        },
        {
          type: "header",
          content: "Layout",
        },
        colSpacing,
      ],
    },
    {
      type: "email",
      name: "Email",
      limit: 1,
      settings: [
        {
          type: "text",
          id: "title",
          label: "Label",
          default: "Email",
        },
        {
          type: "text",
          id: "placeholder",
          label: "Placeholder",
        },
        colSpacing,
      ],
    },
    {
      type: "input",
      name: "Input",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Label",
        },
        {
          type: "text",
          id: "name",
          label: "Element Name",
          info: "This field is used to transfer the data correctly. Using duplicates will make the duplicate fields redundant",
        },
        {
          type: "radio",
          id: "type",
          label: "Type",
          default: "text",
          options: [
            {
              value: "text",
              label: "Text",
            },
            {
              value: "tel",
              label: "Tel",
            },
            {
              value: "number",
              label: "Number",
            },
            {
              value: "email",
              label: "Email",
            },
            {
              value: "date",
              label: "Date",
            },
            {
              value: "url",
              label: "Url",
            },
            {
              value: "checkbox",
              label: "Checkbox",
            },
            {
              value: "hidden",
              label: "Hidden",
            },
          ],
        },
        {
          type: "text",
          id: "placeholder",
          label: "Placeholder",
        },
        {
          type: "checkbox",
          id: "required",
          label: "Required",
          default: false,
        },
        inputAutocomplete,
        colSpacing,
      ],
    },
    {
      type: "hidden",
      name: "Hidden Input",
      settings: [
        {
          type: "text",
          id: "name",
          label: "Element Name",
          info: "You can add any additional properties. There are some reserved keywords that enable extra functionality. I.e. `tags` adds tags to a customer when used in any of the Customer/newsletter related forms",
        },
        {
          type: "text",
          id: "value",
          label: "Value",
          info: "You can use a `comma` to create a list of items.",
        },
      ],
    },
    {
      type: "select",
      name: "Select",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Label",
        },
        {
          type: "text",
          id: "name",
          label: "Element Name",
          info: "This field is used to transfer the data correctly. Using duplicates will make the duplicate fields redundant",
        },
        {
          type: "checkbox",
          id: "all_countries",
          label: "Use All Countries List",
        },
      ],
    },
    {
      type: "Input_group",
      name: "Grouped Input",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Label",
        },
        {
          type: "text",
          id: "name",
          label: "Element Name",
          info: "This field is used to transfer the data correctly. Using duplicates will make the duplicate fields redundant",
        },
        {
          type: "radio",
          id: "type",
          label: "Type",
          default: "radio",
          options: [
            {
              value: "radio",
              label: "Radio",
            },
            {
              value: "checkbox",
              label: "Checkbox",
            },
          ],
        },
      ],
    },
    {
      type: "textarea",
      name: "Textarea",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Label",
        },
        {
          type: "text",
          id: "name",
          label: "Name",
          default: "body",
          info: "Set to `body` for the contact form to use it as a block",
        },
        {
          type: "text",
          id: "placeholder",
          label: "Placeholder",
        },
        {
          type: "range",
          id: "rows",
          label: "Rows",
          default: 4,
          min: 2,
          max: 8,
          step: 1,
        },
        {
          type: "checkbox",
          id: "required",
          label: "Required",
        },
      ],
    },
    {
      type: "buttons",
      name: "Buttons",
      limit: 1,
      settings: [
        {
          type: "header",
          content: "Submit Button",
        },
        {
          type: "text",
          id: "title",
          label: "Label",
          default: "Submit",
        },
        {
          type: "header",
          content: "Reset Button",
        },
        {
          type: "checkbox",
          id: "reset__show",
          label: "Show Reset Button",
        },
        {
          type: "text",
          id: "reset__title",
          label: "Label",
          default: "Reset",
        },
        {
          type: "header",
          content: "Layout",
        },
        {
          type: "checkbox",
          id: "fullwidth",
          label: "Fullwidth",
        },
        colSpacing,
      ],
    },
  ],
  presets: [
    {
      name: "Contact Form",
      settings: {
        type: "contact",
        width: "max-w-2xl",
        fullwidth: true,
        image__overlay: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
        color_scheme: "bg-theme-bg text-theme-text color-inherit",
      },
      blocks: [
        {
          type: "text",
          settings: {
            title: "<p><strong>Lorem Ipsum</strong></p>",
            style: "h2",
            grid_span: "col-span-12",
          },
        },
        {
          type: "text",
          settings: {
            title: "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>",
            style: "h4",
            grid_span: "col-span-12",
          },
        },
        {
          type: "text",
          settings: {
            title:
              "<p>Trade name: Your Business Name Inc.<br/>Phone number: +1 123-456-7891<br/>Email: yourbusinessemail@address.com<br/>Physical address: 3 Industrial Pkwy S, Aurora Ontario L4G 3V9<br/>VAT number: FRXX999999999<br/>Trade number: 123456789</p>",
            style: "richtext",
            grid_span: "col-span-12",
          },
        },
        {
          type: "separator",
          settings: {
            height: 20,
          },
        },
        {
          type: "input",
          settings: {
            title: "Name",
            name: "name",
            type: "text",
            required: false,
            autocomplete: "name",
            grid_span: "col-span-6",
          },
        },
        {
          type: "email",
          settings: {
            title: "Email",
            grid_span: "col-span-6",
          },
        },
        {
          type: "input",
          settings: {
            title: "Phone Number",
            name: "phone number",
            type: "tel",
            required: false,
            autocomplete: "tel",
            grid_span: "col-span-12",
          },
        },
        {
          type: "textarea",
          settings: {
            title: "Message",
            name: "body",
            rows: 4,
          },
        },
        {
          type: "buttons",
          settings: {
            title: "Send",
            fullwidth: true,
            reset__show: false,
            reset__title: "",
          },
        },
      ],
    },
    {
      name: "Newsletter Signup",
      settings: {
        type: "customer",
        width: "max-w-2xl",
        fullwidth: true,
        image__overlay: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
        color_scheme: "bg-theme-bg text-theme-text color-inherit",
      },
      blocks: [
        {
          type: "text",
          settings: {
            title: "<p><strong>Newsletter Signup</strong></p>",
            style: "h3",
            grid_span: "col-span-12",
          },
        },
        {
          type: "separator",
          settings: {
            height: 20,
          },
        },
        {
          type: "email",
          settings: {
            title: "Email",
            grid_span: "col-span-9",
          },
        },
        {
          type: "buttons",
          settings: {
            title: "Subscribe",
            fullwidth: true,
            reset__show: false,
            reset__title: "",
            grid_span: "col-span-3",
          },
        },
        {
          type: "hidden",
          settings: {
            name: "tags",
            value: "newsletter, special, discount",
          },
        },
      ],
    },
    {
      name: "Customer Signup",
      settings: {
        type: "create_customer",
        width: "max-w-md",
        fullwidth: true,
        image__overlay: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
        color_scheme: "bg-theme-bg text-theme-text color-inherit",
      },
      blocks: [
        {
          type: "text",
          settings: {
            title: "<p><strong>Sign Up</strong></p>",
            style: "h2",
            grid_span: "col-span-12",
          },
        },
        {
          type: "text",
          settings: {
            title:
              "<p>Lorem <strong>ipsum </strong>dolor sit amet, consectetur adipiscing elit.</p>",
            style: "richtext",
            grid_span: "col-span-12",
          },
        },
        {
          type: "separator",
          settings: {
            height: 20,
          },
        },
        {
          type: "input",
          settings: {
            title: "First Name",
            name: "first_name",
            type: "text",
            required: false,
            autocomplete: "given-name",
            grid_span: "col-span-12",
          },
        },
        {
          type: "input",
          settings: {
            title: "Last Name",
            name: "last_name",
            type: "text",
            required: false,
            autocomplete: "family-name",
            grid_span: "col-span-12",
          },
        },
        {
          type: "email",
          settings: {
            title: "Email",
            grid_span: "col-span-12",
          },
        },
        {
          type: "password",
          settings: {
            grid_span: "col-span-12",
          },
        },
        {
          type: "buttons",
          settings: {
            title: "Sign Up",
            reset__show: false,
            reset__title: "Reset",
            fullwidth: true,
            grid_span: "col-span-12",
          },
        },
      ],
    },
  ],
};
