import { buttons } from "globals/settings/buttons";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { header } from "sections/header/schema";
import { richtext } from "sections/richtext/schema";
import { ShopifySection } from "types/shopify";
import { ImageFeedSection } from "types/sections";

export const imageFeed: ShopifySection<ImageFeedSection> = {
  name: "Image feed",
  settings: [
    {
      id: "image__aspect_ratio",
      type: "select",
      default: "pb-[100%]",
      options: [
        {
          value: "pb-[75%]",
          label: "Landscape (3:4)",
        },
        {
          value: "pb-[100%]",
          label: "Square (1:1)",
        },
        {
          value: "pb-[125%]",
          label: "Portrait (4:5)",
        },
      ],
      label: "Image ratio",
    },
    {
      type: "range",
      id: "min_width",
      label: "Image Min Width",
      default: 360,
      min: 200,
      max: 640,
      step: 10,
      unit: "px",
    },
    {
      type: "header",
      content: "Layout",
    },
    sectionGlobals.sectionLayout,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  max_blocks: 5,
  blocks: [
    {
      type: "image",
      name: "Image",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Image__overlay",
        },
        {
          type: "header",
          content: "Optional Content",
        },
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        typeRange({ id: "title_font", label: "Title style", default_font: 1 }),
        {
          type: "textarea",
          id: "subtitle",
          label: "Subtitle",
        },
        typeRange({ id: "subtitle_font", label: "Subtitle style", default_font: 2 }),
        {
          type: "header",
          content: "Layout",
        },
        sectionGlobals.responsiveVisibility,
      ],
    },
  ],

  presets: [
    {
      name: "Image feed",
      blocks: [{ type: "image" }, { type: "image" }, { type: "image" }],
    },
  ],
};
