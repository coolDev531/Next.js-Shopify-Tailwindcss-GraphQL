import clsx from "clsx";
import { useGlobalProducts, useLineItems } from "globals/utils/global-stores";
import { MinusIcon, PlusIcon, TimerIcon } from "globals/utils/icons";
import { _Cart_fetch_api_Items } from "globals/utils/types";
import { capitalize } from "globals/utils/utils";
import { FC, useEffect, useState } from "react";
import { _Variant_liquid } from "types/shopify";

export const CartLineItems = () => {
  const { cartData } = useLineItems();

  return (
    <>
      {cartData && cartData.items.length
        ? <>
            {cartData.items.map((line_item) => {
              if (line_item.quantity === 0) return null;
              return <CartLineItem key={line_item.key} line_item={line_item} />;
            })}
          </>
        : "empty State"}
    </>
  );
};

export const CartLineItem: FC<{ line_item: _Cart_fetch_api_Items }> = ({ line_item }) => {
  const { adjustItem } = useLineItems(({ adjustItem }) => ({ adjustItem: adjustItem }));
  const [variant, setVariant] = useState<_Variant_liquid>(null);
  const products = useGlobalProducts((state) => state.products);

  useEffect(() => {
    if (!variant && products[line_item.product_id]) {
      setVariant(
        products[line_item.product_id]?.variants?.find(({ id }) => id === line_item.variant_id)
      );
    }
  }, [line_item.product_id, line_item.variant_id, products, variant]);

  return (
    <tr className="group hf:bg-gray-50">
      <td className="py-4 pl-4 pr-3 text-sm sm:pl-6">
        <div className="grid w-full items-center gap-4 sm:grid-cols-[100px_1fr]">
          <img
            src={`${line_item.image}&crop=center&height=100&width=100`}
            alt={line_item.featured_image?.alt ?? line_item.title}
            width="100"
            height="100"
            className={clsx(
              "w-[100px]",
              !line_item.image && "pointer-events-none hidden overflow-hidden opacity-0"
            )}
          />

          <a className="block flex-1" href={line_item.url}>
            <h3 className="font-semibold group-hf:underline">{line_item.product_title}</h3>
            <h4 className="text-xs uppercase tracking-wide text-gray-500">
              {line_item.variant_title}
            </h4>

            {Object.entries(line_item?.properties ?? {})
              ?.filter(([key]) => !/^_/gi.test(key))
              ?.map(([key, value]) => {
                if (key === "preorder") {
                  return (
                    <p key={key} className="mt-1 flex text-xs text-gray-600 opacity-70">
                      <TimerIcon className="mr-2 h-4 w-4" /> <span>{value}</span>
                    </p>
                  );
                }
                return (
                  <p key={key} className="text-xs text-gray-600">
                    {capitalize(key)}: {value}
                  </p>
                );
              })}

            <div className="mt-1 text-sm font-medium">
              <span
                className={clsx(
                  "text-gray-500 line-through",
                  line_item.original_price === line_item.discounted_price &&
                    "pointer-events-none hidden overflow-hidden opacity-0"
                )}
              >
                {window.formatMoney(line_item.original_price)}{" "}
              </span>
              <span className="text-primary-outline">
                {window.formatMoney(line_item.final_price)}
              </span>
            </div>
          </a>
        </div>
      </td>
      <td className="whitespace-nowrap px-4 py-2 text-sm text-gray-500 max-md:hidden sm:px-6">
        {line_item.sku}
      </td>
      <td className="whitespace-nowrap px-4 py-2 text-right text-sm text-gray-500 max-sm:hidden sm:px-6">
        <div className="relative flex">
          <div className="mr-auto mt-2 flex select-none space-x-2.5 rounded-theme border border-gray-300 px-1.5 py-0.5 text-[13px] font-semibold">
            <button
              type="button"
              className="flex items-center justify-center p-1.5 text-gray-600 hf:text-gray-900"
              onClick={() => adjustItem(line_item, -1)}
            >
              <span className="sr-only">Decrease quantity by 1</span>
              <MinusIcon className="h-2 w-2 stroke-2" />
            </button>
            <span className="text-gray-800">{line_item.quantity}</span>
            <button
              type="button"
              onClick={() => adjustItem(line_item, 1)}
              className="flex items-center justify-center p-1.5 text-gray-600 hf:text-gray-900"
              disabled={
                variant?.inventory_policy === "deny" &&
                variant?.inventory_management === "shopify" &&
                variant?.inventory_quantity - line_item.quantity <= 0
              }
            >
              <span className="sr-only">Increase quantity by 1</span>
              <PlusIcon className="h-2 w-2 stroke-2" />
            </button>
          </div>
          <span className="absolute top-full left-0 mt-0.5 block w-full text-center text-xs">
            <button
              className="text-gray-400 hf:text-gray-500 hf:underline"
              onClick={() => adjustItem(line_item, -line_item.quantity)}
            >
              Remove
            </button>
          </span>
        </div>
      </td>
      <td className="whitespace-nowrap px-4 py-2 text-right text-sm font-medium text-gray-700 sm:px-6">
        {window.formatMoney(line_item.final_line_price)}
        <div className="mb-auto mt-4 sm:hidden">
          <div className="relative flex">
            <div className="mr-auto mt-2 flex select-none space-x-2.5 rounded-theme border border-gray-300 px-1.5 py-0.5 text-[13px] font-semibold">
              <button
                type="button"
                className="flex items-center justify-center p-1.5 text-gray-600 hf:text-gray-900"
                onClick={() => adjustItem(line_item, -1)}
              >
                <span className="sr-only">Decrease quantity by 1</span>
                <MinusIcon className="h-2 w-2 stroke-2" />
              </button>
              <span className="text-gray-800">{line_item.quantity}</span>
              <button
                type="button"
                onClick={() => adjustItem(line_item, 1)}
                className="flex items-center justify-center p-1.5 text-gray-600 hf:text-gray-900"
                disabled={
                  variant?.inventory_policy === "deny" &&
                  variant?.inventory_management === "shopify" &&
                  variant?.inventory_quantity - line_item.quantity <= 0
                }
              >
                <span className="sr-only">Increase quantity by 1</span>
                <PlusIcon className="h-2 w-2 stroke-2" />
              </button>
            </div>
            <span className="absolute top-full left-0 mt-0.5 block w-full text-center text-xs">
              <button
                className="text-gray-400 hf:text-gray-500 hf:underline"
                onClick={() => adjustItem(line_item, -line_item.quantity)}
              >
                Remove
              </button>
            </span>
          </div>
        </div>
      </td>
    </tr>
  );
};
