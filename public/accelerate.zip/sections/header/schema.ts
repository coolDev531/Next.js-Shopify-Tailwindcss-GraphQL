import { sectionGlobals } from "globals/settings/section-globals";
import { logoStyle } from "globals/settings/logo";
import { HeaderSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const header: ShopifySection<HeaderSection> = {
  name: "Header",
  settings: [
    sectionGlobals.colorScheme,
    logoStyle,
    {
      type: "range",
      id: "logo_height",
      label: "Logo height",
      default: 80,
      min: 0,
      max: 100,
      step: 5,
      unit: "%",
    },
    {
      type: "link_list",
      id: "menu",
      default: "main-menu",
      label: "Menu",
    },
    {
      type: "header",
      content: "Layout",
    },
    /*{
      type: "select",
      id: "desktop_layout",
      label: "Layout",
      default: "logo_menu_settings",
      options: [
        {
          group: "Desktop only",
          value: "logo_menu_settings",
          label: "Logo - - Menu - - Settings",
        },
        {
          group: "Desktop only",
          value: "menu_logo_settings",
          label: "Menu - - Logo - - Settings",
        },
        {
          group: "Mobile & Desktop",
          value: "hamburger_logo_settings",
          label: "Hamburger - Logo - - - Settings",
        },
        {
          group: "Mobile & Desktop",
          value: "hamburger_logo_center_settings",
          label: "Hamburger - - Logo - - Settings",
        },
      ],
    },*/
    {
      type: "checkbox",
      id: "force_hamburger_menu",
      label: "Use hamburger menu on desktop",
      default: false,
    },
    {
      type: "checkbox",
      id: "center_logo",
      label: "Center logo with hamburger menu",
      default: false,
    },
    {
      type: "range",
      id: "height",
      label: "Height",
      default: 75,
      min: 40,
      max: 200,
      step: 5,
      unit: "px",
    },
    {
      type: "radio",
      id: "position",
      label: "Position",
      default: "sticky",
      options: [
        {
          value: "sticky",
          label: "Sticky",
        },
        {
          value: "relative",
          label: "Normal",
        },
      ],
    },
  ],
  blocks: [
    {
      type: "megamenu",
      name: "Megamenu",
      settings: [
        {
          type: "text",
          id: "handle",
          label: "Menu Handle",
          info: `While in the theme editor, hover over the menu items in the Header and the handle will appear. This input needs to match the menu item handle where you want the dropdown to show.`,
        },
        {
          type: "range",
          id: "font_scale",
          min: 50,
          max: 150,
          step: 5,
          unit: "%",
          label: "Font size scale",
          default: 100,
        },
        {
          type: "radio",
          id: "rows",
          label: "Rows",
          default: "1",
          options: [
            {
              value: "1",
              label: "1",
            },
            {
              value: "2",
              label: "2",
            },
          ],
        },
        {
          type: "header",
          content: "Images",
        },
        {
          type: "checkbox",
          id: "show_images",
          label: "Show images",
          default: true,
        },
        {
          type: "color_background",
          id: "image_overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.25) 100%)",
        },
        {
          type: "checkbox",
          id: "show_caption",
          label: "Show Caption",
          default: true,
          info: "Default to `title`. Create a text metafield within the Collection, Product or Blog post named: `theme.megamenu_caption` to override.",
        },
        {
          type: "color",
          id: "image_caption_color",
          label: "Caption color",
          default: "#ffffff",
        },
        {
          type: "header",
          content: "Override Images",
        },
        {
          type: "paragraph",
          content:
            "You can override up to 4 images by specifying the dropdown menu handle and adding an image",
        },
        {
          type: "text",
          id: "override_1_handle",
          label: "Handle 1",
        },
        {
          type: "image_picker",
          id: "override_1_image",
          label: "Image 1",
        },
        {
          type: "text",
          id: "override_2_handle",
          label: "Handle 2",
        },
        {
          type: "image_picker",
          id: "override_2_image",
          label: "Image 2",
        },
        {
          type: "text",
          id: "override_3_handle",
          label: "Handle 3",
        },
        {
          type: "image_picker",
          id: "override_3_image",
          label: "Image 3",
        },
        {
          type: "text",
          id: "override_4_handle",
          label: "Handle 4",
        },
        {
          type: "image_picker",
          id: "override_4_image",
          label: "Image 4",
        },
      ],
    },
  ],
};
