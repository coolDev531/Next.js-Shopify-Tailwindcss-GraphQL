import { sectionGlobals } from "globals/settings/section-globals";
import { MainAddressesSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainAddresses: ShopifySection<MainAddressesSection> = {
  name: "Addresses",
  settings: [sectionGlobals.colorScheme],
};
