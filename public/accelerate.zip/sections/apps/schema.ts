import { ShopifySection } from "types/shopify";
import { AppsSection } from "types/sections";

export const apps: ShopifySection<AppsSection> = {
  name: "Apps",
  settings: [],
  blocks: [
    {
      type: "@app",
    },
  ],
  presets: [
    {
      name: "Apps",
    },
  ],
};
