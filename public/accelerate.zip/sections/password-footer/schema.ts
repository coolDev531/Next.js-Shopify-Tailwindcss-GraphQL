import { grayScaleStyle } from "globals/settings/gray-scale-style";
import { logoStyle } from "globals/settings/logo";
import { sectionGlobals } from "globals/settings/section-globals";
import { ShopifySection } from "types/shopify";
import { PasswordFooterSection } from "types/sections";

export const passwordFooter: ShopifySection<PasswordFooterSection> = {
  name: "Password footer",
  settings: [
    sectionGlobals.colorScheme,
    logoStyle,
    {
      type: "header",
      content: "Email Signup",
      info: "Subscribers added automatically to your “accepted marketing” customer list. [Learn more](https://help.shopify.com/manual/customers/manage-customers)",
    },
    {
      type: "checkbox",
      id: "newsletter_show",
      default: true,
      label: "Show email signup",
    },
    {
      type: "text",
      id: "newsletter_heading",
      default: "Subscribe to our emails",
      label: "Heading",
    },
    {
      type: "header",
      content: "Social media icons",
      info: "To display your social media accounts, link them in your theme settings.",
    },
    {
      type: "checkbox",
      id: "social_icons_show",
      default: false,
      label: "Show social media icons",
    },
    {
      type: "header",
      content: "Country/region selector",
      info: "To add a country/region, go to your [payment settings.](/admin/settings/payments)",
    },
    {
      type: "checkbox",
      id: "country_selector_show",
      default: true,
      label: "Enable country/region selector",
    },
    {
      type: "header",
      content: "Language selector",
      info: "To add a language, go to your [language settings.](/admin/settings/languages)",
    },
    {
      type: "checkbox",
      id: "language_selector_show",
      default: true,
      label: "Enable language selector",
    },
    {
      type: "header",
      content: "Bottom Section",
    },
    {
      type: "checkbox",
      id: "policy_links_show",
      label: "Enable show policy links",
      default: true,
    },
    {
      type: "checkbox",
      id: "payment_types_show",
      label: "Show payment icons",
      default: true,
    },
  ],
  blocks: [
    {
      type: "text",
      name: "Text",
      settings: [
        {
          type: "text",
          id: "heading",
          default: "Heading",
          label: "Heading",
        },
        {
          type: "richtext",
          id: "subtext",
          default:
            "<p>Share contact information, store details, and brand content with your customers.</p>",
          label: "Subtext",
        },
        grayScaleStyle,
      ],
    },
    {
      type: "image",
      name: "Image",
      settings: [
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
      ],
    },
  ],
  max_blocks: 3,
  default: {
    blocks: [
      {
        type: "text",
      },
    ],
  },
};
