import { sectionGlobals } from "globals/settings/section-globals";
import { MainAccountSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainAccount: ShopifySection<MainAccountSection> = {
  name: "Account",
  settings: [sectionGlobals.colorScheme],
};
