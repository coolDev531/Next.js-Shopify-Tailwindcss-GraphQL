import { contentBlocks } from "globals/settings/content-blocks";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { ScrollableImagesSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const scrollableImages: ShopifySection<ScrollableImagesSection> = {
  name: "Scrollable images",
  generate_block_files: ["scrollbar_position"],
  settings: [
    {
      type: "color_background",
      id: "overlay",
      label: "Overlay",
      default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
    },
    {
      type: "product_list",
      id: "products",
      label: "Products",
      info: "Select the products to display - the first image will be used",
    },
    {
      type: "collection_list",
      id: "collections",
      label: "Collections",
      info: "Select the collections to display - the first image will be used",
    },
    typeRange({ id: "title_type", label: "Title Type", default_font: 4 }),
    {
      type: "header",
      content: "Layout",
    },
    {
      type: "range",
      id: "min_width_desktop",
      label: "Min Width Desktop",
      default: 240,
      min: 80,
      max: 500,
      step: 10,
      unit: "px",
    },
    {
      type: "range",
      id: "min_width_mobile",
      label: "Min Width Mobile",
      default: 240,
      min: 80,
      max: 500,
      step: 10,
      unit: "px",
    },
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "scrollbar_position",
      name: "Scrollbar Position",
      limit: 1,
      settings: [
        {
          type: "header" as const,
          content: "Layout",
        },
        sectionGlobals.marginBottom,
      ],
    },
    {
      type: "scrollable_image",
      name: "Scrollable Image",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "Content",
        },
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        {
          type: "url",
          id: "url",
          label: "Url",
        },
      ],
    },
    contentBlocks.text,
    contentBlocks.buttonGroup,
    contentBlocks.accentLine,
  ],
  presets: [
    {
      name: "Scrollable images",
    },
  ],
};
