import { maxWidth } from "globals/settings/max-width";
import { sectionGlobals } from "globals/settings/section-globals";
import { MainPageSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainPage: ShopifySection<MainPageSection> = {
  name: "Page",
  settings: [
    maxWidth,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
};
