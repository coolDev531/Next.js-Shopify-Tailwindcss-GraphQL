import { MainSearchInputSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainSearchInput: ShopifySection<MainSearchInputSection> = {
  name: "Search Bar Input",
  settings: [],
};
