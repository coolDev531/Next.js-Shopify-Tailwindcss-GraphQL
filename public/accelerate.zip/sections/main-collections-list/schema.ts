import { sectionGlobals } from "globals/settings/section-globals";
import { ShopifySection } from "types/shopify";
import { MainCollectionsListSection } from "types/sections";

export const mainCollectionsList: ShopifySection<MainCollectionsListSection> = {
  name: "Main collections list",
  settings: [
    {
      id: "pagination_size",
      type: "range",
      min: 8,
      max: 48,
      step: 4,
      default: 16,
      label: "Products per page",
    },
    {
      type: "select",
      id: "columns__desktop",
      default: "lg:grid-cols-4",
      label: "Number of columns on desktop",
      options: [
        {
          value: "lg:grid-cols-1",
          label: "1 column",
        },
        {
          value: "lg:grid-cols-2",
          label: "2 columns",
        },
        {
          value: "lg:grid-cols-3",
          label: "3 columns",
        },
        {
          value: "lg:grid-cols-4",
          label: "4 columns",
        },
        {
          value: "lg:grid-cols-5",
          label: "5 columns",
        },
      ],
    },
    {
      type: "select",
      id: "columns__mobile",
      default: "grid-cols-2",
      label: "Number of columns on mobile",
      options: [
        {
          value: "grid-cols-1",
          label: "1 column",
        },
        {
          value: "grid-cols-2",
          label: "2 columns",
        },
      ],
    },
    sectionGlobals.sectionLayout,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  presets: [
    {
      name: "Main collections list",
    },
  ],
};
