import { globalProducts } from "globals/utils/global-stores";
import { JSONParse } from "globals/utils/utils";
import { render } from "preact";
import React from "react";
import { ProductAddToCartBar } from "sections/product-add-to-cart-bar/product-add-to-cart-bar";
import { ProductBuyButtons } from "sections/product/product.buy_buttons";
import { ProductComplementaryItems } from "sections/product/product.complementary";
import { ProductDescription } from "sections/product/product.description";
import { ProductGalleryHorizontal, ProductGalleryVertical } from "sections/product/product.gallery";
import { ProductImage } from "sections/product/product.image";
import { ProductInventorySlider } from "sections/product/product.inventory";
import { ProductPreOrder } from "sections/product/product.pre_order";
import { ProductPrice } from "sections/product/product.price";
import { ProductSibling } from "sections/product/product.product_sibling";
import { ProductQuantitySelector } from "sections/product/product.quantity_selector";
import { ProductRating } from "sections/product/product.rating";
import { ProductShare } from "sections/product/product.share";
import { ProductSideEffects } from "sections/product/product.side-effects";
import { ProductSku } from "sections/product/product.sku";
import { ProductTitle } from "sections/product/product.title";
import { ProductVariantSelector } from "sections/product/product.variant_selector";
import { ProductVendor } from "sections/product/product.vendor";
import { ProductAddToCartBarSection, ProductBlocks, ProductBlocksBuy_buttons, ProductBlocksComplementary, ProductBlocksDescription, ProductBlocksImage, ProductBlocksInventory, ProductBlocksPre_order, ProductBlocksProduct_sibling, ProductBlocksVariant_selector, ProductSection } from "types/sections";
import { _Product_liquid, _Variant_liquid } from "types/shopify";
import createReact from "zustand";

export type ReactProductState = {
  product: _Product_liquid;
  selectedVariant: _Variant_liquid;
  formId: string;
  setSelectedVariant: (variantId: number) => void;
  setOptionsVariant: (optionIndex: number, value: string) => void;
  options: string[];
  setQuantity: (quantity: number) => void;
  quantity: number;
  updateProduct: (product: _Product_liquid) => void;
  setSiblingProduct: (product: _Product_liquid) => void;
  productSiblings: ProductSiblingGroup[] | null;
};

export const initProductStore = (
  productSection: HTMLElement,
  productId: string,
  formId: string
) => {
  const { getProduct } = globalProducts.getState();

  const product = getProduct(productId);

  const productSiblings = JSONParse(
    document.querySelector("[data-product-siblings]")?.innerHTML
  ) as ProductSiblingGroup[];

  if (!product) {
    return null;
  }

  return (set, get) => {
    return {
      product,
      productSiblings,
      formId,
      selectedVariant: product.selected_or_first_available_variant,
      options: [...product.selected_or_first_available_variant.options],
      quantity: 1,
      setQuantity: (quantity) => set({ quantity }),
      setSelectedVariant: (variantId) => {
        const selectedVariant = get().product.variants.find((variant) => variant.id === variantId);

        set({
          selectedVariant,
          options: [...selectedVariant.options],
          quantity: 1,
        });
      },
      setOptionsVariant: (optionIndex, value) => {
        let options = get().options;
        options[optionIndex] = value;
        const variants = get().product.variants;
        const selectedVariant =
          variants.find(
            (v) => v.options.every((option, index) => option === options[index]) && v.available
          ) ??
          variants.find((v) => v.options.every((option, index) => option === options[index])) ??
          variants.find((variant) => variant.options[optionIndex] === value && variant.available) ??
          variants.find((variant) => variant.available) ??
          variants.find((variant) => variant);

        options = [...selectedVariant.options];

        set({
          options,
          selectedVariant,
          quantity: 1,
        });
      },
      updateProduct: (product) => {
        const selectedVariant =
          product?.variants?.find((variant) => variant.id === get().selectedVariant.id) ??
          product?.selected_or_first_available_variant ??
          product?.variants?.[0];

        set({
          options: [...selectedVariant.options],
          product,
          selectedVariant,
          quantity: 1,
        });
      },
      setSiblingProduct: (product) => {
        const selectedVariant =
          product.variants.find((variant) => variant.id === get().selectedVariant.id) ??
          product.selected_or_first_available_variant ??
          product.variants[0];

        window.history.replaceState(
          null,
          product.title,
          `${product.handle}?variant=${selectedVariant?.id}`
        );

        set({
          options: [...selectedVariant.options],
          product,
          selectedVariant,
          quantity: 1,
        });
      },
    };
  };
};

export const initProducts = () => {
  document.querySelectorAll<HTMLElement>("[data-product-id]").forEach((productSection) => {
    initProduct(productSection);
  });
};

export type ProductSiblingGroup = {
  title: string;
  options: string;
  products: { id: number; handle: string; image?: string }[];
};

export const initProduct = (productSection: HTMLElement) => {
  const productId = productSection.dataset.productId;
  const formId = productSection.dataset.productFormId;
  const useProduct = createReact(initProductStore(productSection, productId, formId));

  const sectionSettings = JSONParse(
    productSection.querySelector(`[data-section-settings]`)?.innerHTML
  ) as ProductSection["settings"];

  productSection.querySelectorAll<HTMLElement>(`[data-product-block]`).forEach((block) => {
    const type = block.dataset.productBlock as ProductBlocks["type"] | "side_effects";
    // console.log({ type, settings: block.dataset.blockSettings });
    const settings = block.dataset.blockSettings ? JSONParse(block.dataset.blockSettings) : null;

    switch (type) {
      case "@app":
        return;
      case "text":
        return;
      case "title":
        render(<ProductTitle useProduct={useProduct} />, block);
        return;
      case "vendor":
        render(<ProductVendor useProduct={useProduct} />, block);
        return;
      case "description":
        render(
          <ProductDescription
            settings={settings as ProductBlocksDescription["settings"]}
            useProduct={useProduct}
          />,
          block
        );
        return;
      case "share":
        render(<ProductShare useProduct={useProduct} />, block);
        return;
      case "custom_liquid":
        return;
      case "collapsible_tab":
        return;
      case "rating":
        render(<ProductRating useProduct={useProduct} />, block);
        return;
      case "complementary":
        render(
          <ProductComplementaryItems
            settings={settings as ProductBlocksComplementary["settings"]}
            useProduct={useProduct}
          />,
          block
        );
        return;
      case "icon_with_text":
        return;
      case "price": {
        block.innerHTML = "";
        render(<ProductPrice useProduct={useProduct} />, block);
        return;
      }
      case "variant_selector": {
        block.innerHTML = "";
        render(
          <ProductVariantSelector
            useProduct={useProduct}
            settings={settings as ProductBlocksVariant_selector["settings"]}
          />,
          block
        );
        return;
      }
      case "product_sibling": {
        block.innerHTML = "";
        render(
          <ProductSibling
            useProduct={useProduct}
            settings={settings as ProductBlocksProduct_sibling["settings"]}
          />,
          block
        );
        return;
      }
      case "sku": {
        block.innerHTML = "";
        render(<ProductSku useProduct={useProduct} />, block);
        return;
      }
      case "quantity_selector": {
        block.innerHTML = "";
        console.log({ type });
        render(<ProductQuantitySelector useProduct={useProduct} />, block);
        return;
      }
      case "buy_buttons": {
        block.innerHTML = "";
        render(
          <ProductBuyButtons
            useProduct={useProduct}
            settings={settings as ProductBlocksBuy_buttons["settings"]}
          />,
          block
        );
        return;
      }
      case "dynamic_buy_buttons": {
        return;
      }
      case "inventory": {
        block.innerHTML = "";
        render(
          <ProductInventorySlider
            settings={settings as ProductBlocksInventory["settings"]}
            useProduct={useProduct}
          />,
          block
        );
        return;
      }
      case "image": {
        render(
          <ProductImage
            settings={settings as ProductBlocksImage["settings"]}
            useProduct={useProduct}
          />,
          block
        );
        return;
      }
      case "side_effects": {
        block.innerHTML = "";
        render(<ProductSideEffects useProduct={useProduct} />, block);
        return;
      }
      case "pre_order": {
        block.innerHTML = "";
        render(
          <ProductPreOrder
            settings={settings as ProductBlocksPre_order["settings"]}
            useProduct={useProduct}
          />,
          block
        );
        return;
      }
    }
  });

  productSection
    .querySelectorAll<HTMLElement>(`[data-product-media-gallery]`)
    .forEach((galleryElement) => {
      const type = galleryElement.dataset.productMediaGallery as "horizontal" | "vertical";

      switch (type) {
        case "horizontal":
          render(
            <ProductGalleryHorizontal settings={sectionSettings} useProduct={useProduct} />,
            galleryElement
          );
          return;
        case "vertical":
          render(
            <ProductGalleryVertical settings={sectionSettings} useProduct={useProduct} />,
            galleryElement
          );
          return;
      }
    });

  const root = document.querySelector<HTMLElement>("[data-product-add-to-cart-bar]");
  const productAddToCartBarUpsellProduct = root?.dataset?.productAddToCartBarUpsellProduct;
  root.innerHTML = "";

  if (root) {
    render(
      <ProductAddToCartBar
        useProduct={useProduct}
        upsellProductId={productAddToCartBarUpsellProduct}
      />,
      root
    );
  }
};
