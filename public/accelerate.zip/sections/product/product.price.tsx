import { FC } from "react";
import { ReactProductState } from "sections/product/product";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductPrice: FC<{ useProduct: UseBoundStore<StoreApi<ReactProductState>> }> = ({
  useProduct,
}) => {
  const variant = useProduct(({ selectedVariant }) => selectedVariant);

  return (
    <div className=" grid auto-cols-min grid-flow-col-dense items-baseline gap-2 whitespace-nowrap text-sm font-semibold">
      <span>{window.formatMoney(variant?.price)}</span>
      {variant?.compare_at_price > variant?.price
        ? <span className="text-xs text-theme-text/50 line-through">
            {window.formatMoney(variant?.compare_at_price)}
          </span>
        : null}
    </div>
  );
};
