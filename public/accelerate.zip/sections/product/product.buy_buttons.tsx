import clsx from "clsx";
import { cart } from "globals/utils/cart";
import { LoadingSpinner } from "globals/utils/loading-spinner";
import { FC, useCallback, useState } from "react";
import { ReactProductState } from "sections/product/product";
import { ProductBlocksBuy_buttons } from "types/sections";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductBuyButtons: FC<{
  settings?: ProductBlocksBuy_buttons["settings"];
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}> = ({ useProduct, settings }) => {
  const { selectedVariant, quantity, formId } = useProduct();
  const [loading, setLoading] = useState(false);
  const pre_order = selectedVariant.metafields.accelerate?.pre_order;
  const pre_order_date = selectedVariant.metafields.accelerate?.pre_order_date;

  const handleSubmit = useCallback(
    async (e) => {
      e.preventDefault();
      setLoading(true);
      if (pre_order && selectedVariant.inventory_quantity < quantity) {
        const now_date = Date.now();
        let label = "Preorder Shipping this week";
        let timeOfMonth = "early ";

        if (pre_order_date) {
          const target_date = new Date(pre_order_date as string).getTime();
          const target_day = +new Date(pre_order_date as string).toLocaleString("en", {
            day: "2-digit",
          });
          const target_month = new Date(pre_order_date as string).toLocaleString("en", {
            month: "long",
          });
          const difference = Math.round((target_date - now_date) / 1000 / 60 / 60 / 24);

          if (target_day > 7) {
            timeOfMonth = "mid ";
          }
          if (target_day > 20) {
            timeOfMonth = "end of ";
          }

          if (difference > 7) {
            label = "Preorder Shipping next week";
          }
          if (difference > 15) {
            label = "Preorder Shipping end of the month";
          }
          if (difference > 31) {
            label = "Preorder Shipping early next month";
          }
          if (difference > 45) {
            label = `Preorder Shipping ${timeOfMonth} ${target_month}`;
          }

          if (selectedVariant.inventory_quantity > 0) {
            await cart.add(
              {
                items: [
                  {
                    id: selectedVariant.id,
                    quantity: selectedVariant.inventory_quantity,
                  },
                  {
                    id: selectedVariant.id,
                    quantity: quantity - selectedVariant.inventory_quantity,
                    properties: {
                      preorder: label,
                    },
                  },
                ],
              },
              true
            );
          }

          if (selectedVariant.inventory_quantity <= 0) {
            await cart.add(
              {
                items: [
                  {
                    id: selectedVariant.id,
                    quantity: quantity,
                    properties: {
                      preorder: label,
                    },
                  },
                ],
              },
              true
            );
          }
        }
      }
      if (!pre_order || selectedVariant.inventory_quantity >= quantity) {
        await cart.add(
          {
            items: [
              {
                id: selectedVariant.id,
                quantity,
              },
            ],
          },
          true
        );
      }

      setLoading(false);
    },
    [pre_order, pre_order_date, quantity, selectedVariant.id, selectedVariant.inventory_quantity]
  );

  return (
    <form
      method="post"
      action="/cart/add"
      id={formId}
      acceptCharset="UTF-8"
      encType="multipart/form-data"
      noValidate={true}
      onSubmit={handleSubmit}
    >
      <input type="hidden" name="form_type" value="product" />
      <input type="hidden" name="utf8" value="✓" />
      <input type="hidden" name="id" value={selectedVariant.id} />
      <button
        type="submit"
        name="add"
        disabled={!selectedVariant.available}
        className={clsx("w-full", settings?.button__style ?? "button-primary")}
      >
        <span>
          {!selectedVariant
            ? "Unavailable"
            : selectedVariant.available
            ? "Add to Cart"
            : "Sold Out"}
        </span>
        <LoadingSpinner loading={loading} />
      </button>
    </form>
  );
};
