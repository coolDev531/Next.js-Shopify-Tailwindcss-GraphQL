import { FC } from "react";
import { ReactProductState } from "sections/product/product";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductTitle: FC<{ useProduct: UseBoundStore<StoreApi<ReactProductState>> }> = ({
  useProduct,
}) => {
  const { product } = useProduct();
  return <h1 className="h3 font-bold">{product.title}</h1>;
};
