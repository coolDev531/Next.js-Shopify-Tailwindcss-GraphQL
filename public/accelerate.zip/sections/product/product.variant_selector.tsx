import { ChevronUpDownIcon } from "globals/utils/icons";
import { toKebabCase } from "globals/utils/utils";
import { FC } from "react";
import { ReactProductState } from "sections/product/product";
import { ProductBlocksVariant_selector } from "types/sections";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductVariantSelector: FC<{
  settings: ProductBlocksVariant_selector["settings"];
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}> = ({ settings, useProduct }) => {
  const { product, selectedVariant, formId, setSelectedVariant, options, setOptionsVariant } =
    useProduct();

  if (
    settings?.image_selector &&
    product.variants.length <= 12 &&
    product.variants.length > 1 &&
    product.variants.every((v) => v.featured_media?.preview_image)
  ) {
    return (
      <div>
        <h3 className="text-sm font-semibold">{product.options.join(" / ")}:</h3>
        <div className="relative pt-6">
          <fieldset className="group grid grid-cols-[repeat(auto-fill,3.5rem)] gap-1">
            {product.variants.map((variant) => (
              <label className="cursor-pointer" key={variant.id}>
                <input
                  type="radio"
                  name="variant-image-selector"
                  value={variant.id}
                  form={formId}
                  checked={variant.id === selectedVariant.id}
                  className="peer absolute appearance-none outline-none hfa:outline-none"
                  onChange={() => {
                    setSelectedVariant(variant.id);
                  }}
                  disabled={settings.disable_unavailable && !variant.available}
                />
                <picture
                  data-product-vs-variant-title={variant.title}
                  className="flex h-14 w-14 overflow-hidden rounded-theme-md border-2 border-transparent bg-theme-bg before:absolute peer-checked:border-theme-text peer-disabled:cursor-not-allowed peer-disabled:opacity-60 hf:border-theme-text/60 peer-disabled:hf:opacity-70 b:pointer-events-none b:top-0 b:left-0 b:text-xs b:text-theme-text/80 b:opacity-0 b:content-[attr(data-product-vs-variant-title)] peer-checked:b:opacity-100 hf:b:!opacity-100 group-hfa:b:opacity-0 peer-hfwa:border-primary-outline"
                >
                  <img
                    src={`${variant.featured_media?.preview_image?.src}&width=60&height=60`}
                    alt={variant.featured_media?.alt ?? variant.title}
                    className="pointer-events-none h-full w-full object-cover object-center"
                  />
                </picture>
              </label>
            ))}
          </fieldset>
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-2">
      {product.variants.length === 1
        ? null
        : <>
            {product.options_with_values.map(({ name, position, values }) => {
              const index = position - 1;
              const isColorSelector =
                settings?.color_selector &&
                settings?.color_list
                  .split(",")
                  .map((color) => color.trim().toLowerCase())
                  .includes(name.toLowerCase());

              if (isColorSelector) {
                return (
                  <div key={name} className="relative order-first">
                    <h3 className="text-sm font-semibold">{name}</h3>
                    <fieldset className="group mt-2 flex flex-wrap gap-2">
                      {values.map((value) => (
                        <label
                          key={value}
                          className="cursor-pointer rounded-full border border-theme-text/50"
                          title={value}
                        >
                          <input
                            type="radio"
                            name={`variant-selector-${product.id}-${name}`}
                            className="peer absolute appearance-none outline-none hfa:outline-none"
                            value={value}
                            onChange={() => {
                              setOptionsVariant(index, value);
                            }}
                            checked={options[index] === value}
                            disabled={
                              settings?.disable_unavailable &&
                              !product.variants.some((variant) => {
                                switch (index) {
                                  case 0: {
                                    return variant.options[index] === value && variant.available;
                                  }
                                  case 1: {
                                    return (
                                      variant.options[0] === options[0] &&
                                      variant.options[index] === value &&
                                      variant.available
                                    );
                                  }
                                  case 2: {
                                    return (
                                      variant.options[0] === options[0] &&
                                      variant.options[1] === options[1] &&
                                      variant.options[index] === value &&
                                      variant.available
                                    );
                                  }
                                }
                                return false;
                              })
                            }
                          />

                          <span
                            className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full ring-2 ring-transparent ring-offset-1 peer-checked:ring-theme-text peer-disabled:cursor-not-allowed peer-disabled:opacity-60 svg:opacity-0 peer-checked:svg:opacity-100 hf:ring-primary-outline peer-disabled:hf:opacity-70"
                            style={{
                              background: `var(--color-swatch--${toKebabCase(value)}, ${value})`,
                            }}
                          ></span>
                        </label>
                      ))}
                    </fieldset>
                  </div>
                );
              }
              if (settings.default_type === "radio") {
                return (
                  <div key={name} className="relative">
                    <h3 className="text-sm font-semibold">{name}</h3>
                    <fieldset className="group flex flex-wrap gap-1.5">
                      {values.map((value) => (
                        <label key={value} className="cursor-pointer select-none">
                          <input
                            type="radio"
                            name={`variant-selector-${product.id}-${name}`}
                            value={value}
                            onChange={() => {
                              setOptionsVariant(index, value);
                            }}
                            checked={options[index] === value}
                            disabled={
                              settings.disable_unavailable &&
                              !product.variants.some((variant) => {
                                switch (index) {
                                  case 0: {
                                    return variant.options[index] === value && variant.available;
                                  }
                                  case 1: {
                                    return (
                                      variant.options[0] === options[0] &&
                                      variant.options[index] === value &&
                                      variant.available
                                    );
                                  }
                                  case 2: {
                                    return (
                                      variant.options[0] === options[0] &&
                                      variant.options[1] === options[1] &&
                                      variant.options[index] === value &&
                                      variant.available
                                    );
                                  }
                                }
                                return false;
                              })
                            }
                            className="peer absolute appearance-none outline-none hfa:outline-none"
                          />
                          <span className="block max-w-[200px] truncate whitespace-nowrap rounded-theme-md border-2 border-transparent bg-theme-text/10 px-2.5 py-1.5 text-xs peer-checked:border-theme-text peer-disabled:cursor-not-allowed peer-disabled:opacity-60 hf:border-primary-outline peer-disabled:hf:opacity-70">
                            {value}
                          </span>
                        </label>
                      ))}
                    </fieldset>
                  </div>
                );
              }

              return (
                <label key={name} className="relative">
                  <span className="text-sm font-semibold">{name}</span>
                  <select
                    className="input-primary relative grid w-full appearance-none pr-6 accent-primary-bg"
                    onChange={(e) => {
                      setOptionsVariant(index, (e.target as HTMLSelectElement)?.value);
                    }}
                    value={options[index]}
                  >
                    {values.map((value) => (
                      <option
                        key={value}
                        value={value}
                        className="disabled:text-theme-text/50"
                        selected={options[index] === value}
                        disabled={
                          settings.disable_unavailable &&
                          !product.variants.some((variant) => {
                            switch (index) {
                              case 0: {
                                return variant.options[index] === value && variant.available;
                              }
                              case 1: {
                                return (
                                  variant.options[0] === options[0] &&
                                  variant.options[index] === value &&
                                  variant.available
                                );
                              }
                              case 2: {
                                return (
                                  variant.options[0] === options[0] &&
                                  variant.options[1] === options[1] &&
                                  variant.options[index] === value &&
                                  variant.available
                                );
                              }
                            }
                            return false;
                          })
                        }
                      >
                        {value}
                      </option>
                    ))}
                  </select>
                  <ChevronUpDownIcon className="pointer-events-none absolute right-2 bottom-0 my-2.5 h-5 w-5 text-theme-text/70" />
                </label>
              );
            })}
          </>}
    </div>
  );
};
