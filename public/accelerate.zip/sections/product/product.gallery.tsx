import clsx from "clsx";
import { Image } from "globals/utils/image";
import { ScrollBar, ScrollBarButtons } from "globals/utils/scrollbar";
import { scrollToX, scrollToY, shortUUID } from "globals/utils/utils";
import { FC, useEffect, useRef } from "react";
import { ReactProductState } from "sections/product/product";
import { ProductSection } from "types/sections";
import { _Media_liquid } from "types/shopify";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductGalleryHorizontal: FC<{
  settings: ProductSection["settings"];
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}> = ({ settings, useProduct }) => {
  const { product, setSelectedVariant, selectedVariant } = useProduct();

  const scrollContainer = useRef<HTMLDivElement>(null);
  const mediaItems = [
    selectedVariant.featured_media,
    ...(((selectedVariant.metafields.accelerate?.images as string[])?.map((url) => ({
      aspect_ratio: 1,
      height: 1,
      id: shortUUID(),
      media_type: "image",
      position: -1,
      preview_image: {
        aspect_ratio: 1,
        height: 1,
        src: url,
        width: 1,
      },
      src: url,
      width: 1,
    })) ?? []) as unknown as _Media_liquid[]),
    ...product.media.filter((media) => media.id !== selectedVariant.featured_media?.id),
  ].filter((media) => media);

  useEffect(() => {
    if (!window?.Shopify.designMode) {
      scrollToX(0, 0, scrollContainer.current);
    }
  }, [selectedVariant]);

  return (
    <>
      <main className="scroll-container relative grid">
        <div
          className="scrollbar-none md:min-h-56 flex max-w-full flex-1 snap-x snap-mandatory gap-8 overflow-x-auto scroll-smooth pb-8"
          ref={scrollContainer}
        >
          {mediaItems?.map((media) => {
            return (
              <figure
                key={`media-${media.id}`}
                className="relative grid aspect-1 min-w-full snap-start snap-always pt-[100%] transition-all ease-in-out md:aspect-[unset] md:min-w-full"
              >
                {
                  {
                    image: (
                      <Image
                        src={`${media.src}`}
                        maxWidth={1200}
                        alt={media.alt ?? product.title}
                        className="absolute top-0 left-0 h-full w-full bg-inherit object-contain object-center"
                        screenPercentage={70}
                      />
                    ),
                    video: (
                      <video
                        playsInline={true}
                        controls={true}
                        autoPlay={true}
                        loop={settings.gallery__loop_videos}
                        preload="none"
                        className="absolute top-0 left-0 h-full w-full bg-inherit object-contain"
                        muted={true}
                        aria-label={media.alt ?? product.title}
                        poster={media.preview_image.src}
                      >
                        <source
                          src={
                            media?.sources?.find((src) => src.format === "mp4" && src.width <= 852)
                              ?.url
                          }
                          type="video/mp4"
                        />

                        <Image
                          src={media.preview_image.src}
                          alt={media.alt ?? product.title}
                          screenPercentage={60}
                        />
                      </video>
                    ),
                    external_video: (
                      <iframe
                        frameBorder="0"
                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen={true}
                        className="js-youtube absolute top-0 left-0 h-full w-full border-0 bg-inherit object-contain"
                        loading="lazy"
                        src={
                          media.host === "youtube"
                            ? `https://www.youtube.com/embed/${
                                media.external_id
                              }?autoplay=0&controls=1&muted=1&enablejsapi=1&loop=${
                                settings.gallery__loop_videos ? 1 : 0
                              }&modestbranding=1&playsinline=1&rel=0`
                            : `https://player.vimeo.com/video/${media.external_id}`
                        }
                        title={media.alt ?? product.title}
                      ></iframe>
                    ),
                    model: (
                      <span className="absolute top-0 left-0 block h-full w-full pb-[100%]">
                        {/* @ts-ignore */}
                        <model-viewer
                          className="absolute top-0 left-0 h-full w-full bg-inherit object-contain"
                          style="--poster-color: transparent; position: absolute;"
                          src={media.sources?.find((source) => source.format === "glb")?.url}
                          camera-controls="true"
                          data-shopify-feature="1.12"
                          alt={media.alt ?? product.title}
                          poster={media.preview_image.src}
                          data-js-focus-visible=""
                          ar-status="not-presenting"
                        />
                      </span>
                    ),
                  }[media.media_type]
                }
              </figure>
            );
          })}
          <ScrollBarButtons itemCount={mediaItems.length} />
          <ScrollBar itemCount={mediaItems.length} showCount={true} />
        </div>
      </main>

      {settings.gallery__show_thumbnails
        ? <footer className="scrollbar-x-slim relative mt-12 flex min-h-[100px] flex-1 gap-1 overflow-x-auto pb-2">
            {product?.variants
              .filter(
                (v1, i, a) =>
                  a.findIndex((v2) => v1?.featured_media?.id === v2?.featured_media?.id) === i
              )
              .map((variant) => {
                if (!variant.featured_media) return null;
                return (
                  <button
                    key={`thumbnail-${variant.featured_media.id}`}
                    className="relative grid h-[100px] shrink-0 border border-gray-200"
                    onClick={() => {
                      setSelectedVariant(variant.id);
                    }}
                  >
                    <Image
                      src={`${variant.featured_media?.src}`}
                      alt={variant.featured_media?.alt ?? variant.title}
                      width={Math.round(variant.featured_media.aspect_ratio * 100)}
                      height={100}
                      className="h-full w-full object-contain"
                      screenPercentage={10}
                    />
                  </button>
                );
              })}
          </footer>
        : null}
    </>
  );
};

export const ProductGalleryVertical: FC<{
  settings: ProductSection["settings"];
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}> = ({ settings, useProduct }) => {
  const lastVariantId = useRef<number>(null);
  const { product, setSelectedVariant, selectedVariant } = useProduct();

  const scrollContainer = useRef<HTMLElement>(null);

  const mediaItems = [
    selectedVariant.featured_media,
    ...(((selectedVariant.metafields.accelerate?.images as string[])?.map((url) => ({
      aspect_ratio: 1,
      height: 1,
      id: shortUUID(),
      media_type: "image",
      position: -1,
      preview_image: {
        aspect_ratio: 1,
        height: 1,
        src: url,
        width: 1,
      },
      src: url,
      width: 1,
    })) ?? []) as unknown as _Media_liquid[]),
    ...product.media.filter((media) => media.id !== selectedVariant.featured_media?.id),
  ].filter((media) => media);
  let imageOdd = 0;

  useEffect(() => {
    if (!lastVariantId.current) {
      lastVariantId.current = selectedVariant.id;
    }
    if (!window?.Shopify.designMode && lastVariantId.current !== selectedVariant.id) {
      lastVariantId.current = selectedVariant.id;
      scrollToY(500, scrollContainer.current.offsetTop);
    }
  }, [selectedVariant]);

  return (
    <>
      {settings.gallery__show_thumbnails
        ? <aside className="scrollbar-none sticky grid h-min max-h-[calc(100vh-var(--top-bar-spacing)-4rem)] gap-1 overflow-y-auto pr-1 top-spacing-8">
            {product?.variants
              .filter(
                (v1, i, a) =>
                  a.findIndex((v2) => v1?.featured_media?.id === v2?.featured_media?.id) === i
              )
              .map((variant) => {
                if (!variant.featured_media) return null;
                return (
                  <button
                    key={`thumbnail-${variant.featured_media.id}`}
                    className="relative grid h-full w-full border border-gray-200"
                    onClick={() => {
                      setSelectedVariant(variant.id);
                    }}
                  >
                    <Image
                      src={`${variant.featured_media?.src}`}
                      alt={variant.featured_media?.alt ?? variant.title}
                      width={100}
                      height={Math.round((1 / variant.featured_media.aspect_ratio) * 100)}
                      className="h-full w-full object-contain"
                      screenPercentage={10}
                    />
                  </button>
                );
              })}
          </aside>
        : null}

      <main
        ref={scrollContainer}
        className={clsx(
          "grid",
          settings.gallery__layout === "vertical" ? "gap-6" : "grid-cols-2 gap-3"
        )}
      >
        {mediaItems.map((media, index) => {
          const count = index + 1;
          let order = count * 100;
          const isGrid = settings.gallery__layout === "grid";
          let gridClasses = "";
          if (isGrid && media.aspect_ratio > 1.75) {
            gridClasses = "col-span-2";

            if (count % 2 === imageOdd) {
              imageOdd = imageOdd ? 0 : 1;
              order = order + 150;
            }
          }
          return (
            <figure
              key={media.id}
              className={clsx(
                "relative grid h-full w-full rounded-theme-sm transition-all  ease-in-out ac:overflow-hidden ac:ring ac:ring-primary-outline",
                gridClasses
              )}
              style={{ order: `${order}` }}
            >
              {
                {
                  image: (
                    <Image
                      src={`${media.src}`}
                      maxWidth={1200}
                      alt={media.alt ?? product.title}
                      className="h-full w-full bg-inherit object-contain"
                      screenPercentage={70}
                    />
                  ),
                  video: (
                    <video
                      playsInline={true}
                      controls={true}
                      autoPlay={true}
                      loop={settings.gallery__loop_videos}
                      preload="none"
                      className="h-full w-full bg-inherit object-contain"
                      muted={true}
                      aria-label={media.alt ?? product.title}
                      poster={media.preview_image.src}
                    >
                      <source
                        src={
                          media?.sources?.find((src) => src.format === "mp4" && src.width <= 852)
                            ?.url
                        }
                        type="video/mp4"
                      />
                      <Image
                        src={media.preview_image.src}
                        alt={media.alt ?? product.title}
                        screenPercentage={60}
                      />
                    </video>
                  ),
                  external_video: (
                    <iframe
                      frameBorder="0"
                      allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen={true}
                      className={clsx(
                        "h-full w-full border-0 bg-inherit object-contain",
                        media.host === "youtube" ? "js-youtube" : "js-vimeo"
                      )}
                      loading="lazy"
                      src={
                        media.host === "youtube"
                          ? `https://www.youtube.com/embed/${
                              media.external_id
                            }?autoplay=0&controls=1&muted=1&enablejsapi=1&loop=${
                              settings.gallery__loop_videos ? 1 : 0
                            }&modestbranding=1&playsinline=1&rel=0`
                          : `https://player.vimeo.com/video/${media.external_id}`
                      }
                      title={media.alt ?? product.title}
                    ></iframe>
                  ),
                  model: (
                    <>
                      <span
                        className="relative top-0 left-0 block h-full w-full"
                        style={{
                          paddingBottom: `calc(100% * ${media.preview_image.aspect_ratio})`,
                        }}
                      />
                      <span className="absolute top-0 left-0 block h-full w-full pb-[100%]">
                        {/* @ts-ignore */}
                        <model-viewer
                          className="h-full w-full bg-inherit object-contain"
                          style="--poster-color: transparent; position: absolute;"
                          src={media.sources?.find((source) => source.format === "glb")?.url}
                          camera-controls="true"
                          data-shopify-feature="1.12"
                          alt={media.alt ?? product.title}
                          poster={media.preview_image.src}
                          data-js-focus-visible=""
                          ar-status="not-presenting"
                        />
                      </span>
                    </>
                  ),
                }[media.media_type]
              }
            </figure>
          );
        })}
      </main>
    </>
  );
};
