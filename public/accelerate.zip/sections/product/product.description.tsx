import { Accordion } from "globals/utils/accordion";
import React, { FC } from "react";
import { ReactProductState } from "sections/product/product";
import { ProductBlocksDescription } from "types/sections";
import { StoreApi, UseBoundStore } from "zustand";

export const ProductDescription: FC<{
  settings: ProductBlocksDescription["settings"];
  useProduct: UseBoundStore<StoreApi<ReactProductState>>;
}> = ({ settings, useProduct }) => {
  const { product } = useProduct();

  const div = document.createElement("div");

  return (
    <div className="grid gap-3">
      {settings.accordion_style
        ? <>
            {product.description.split("<h1").map((headingBlock, index) => {
              if (!headingBlock.includes("</h1>")) {
                div.innerHTML = headingBlock;
                return (
                  <div key={index} className="grid gap-3">
                    {div.textContent}
                  </div>
                );
              }
              if (headingBlock.includes("</h1>")) {
                const [rawTitle, rawContent] = headingBlock.split("</h1>");
                div.innerHTML = `<h1${rawTitle}</h1>`;
                const title = div.textContent;
                div.innerHTML = rawContent;
                const content = div.textContent;
                div.remove();

                return (
                  <div key={index} className="grid gap-3 border-b border-b-theme-text/50">
                    <Accordion title={title} content={content} />
                  </div>
                );
              }
              return null;
            })}
          </>
        : <div
            className="prose prose-theme"
            dangerouslySetInnerHTML={{ __html: product.description }}
          />}
    </div>
  );
};
