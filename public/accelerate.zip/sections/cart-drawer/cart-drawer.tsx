import clsx from "clsx";
import { cartDrawer, useGlobalProducts, useLineItems } from "globals/utils/global-stores";
import { CloseIcon, MinusIcon, PlusIcon, TimerIcon } from "globals/utils/icons";
import { ScrollBar } from "globals/utils/scrollbar";
import { _Cart_fetch_api, _Cart_fetch_api_Items } from "globals/utils/types";
import { useDebouncedEffect } from "globals/utils/use-debounce-effect";
import { capitalize, JSONParse } from "globals/utils/utils";
import { render } from "preact";
import { FC, useCallback, useEffect, useMemo, useState } from "react";
import { CartLineItems } from "sections/main-cart/main-cart";
import { useProductDrawer } from "sections/product-drawer/product-drawer";
import { CartDrawerSection } from "types/sections";
import { _Product_liquid, _Variant_liquid } from "types/shopify";

export const CartDrawerLineItems = () => {
  const { cartData } = useLineItems();

  return (
    <>
      {cartData && cartData.items.length
        ? <>
            {cartData.items.map((line_item) => {
              if (line_item.quantity === 0) return null;
              return <CartDrawerLineItem key={line_item.key} line_item={line_item} />;
            })}
          </>
        : ""}
    </>
  );
};

export const CartSideEffects = () => {
  const { preloadProduct, hydrated } = useGlobalProducts(({ preloadProduct, hydrated }) => ({
    preloadProduct,
    hydrated,
  }));
  const cartCountItems = document.querySelectorAll<HTMLElement>("[data-cart-item-count]");
  const loadingSpinner = document.querySelectorAll<HTMLElement>(
    `[data-drawer="cart"] [data-loading-spinner], [data-cart-content] [data-loading-spinner]`
  );
  const cartTotals = document.querySelectorAll<HTMLElement>("[data-cart-total]");
  const { cartData, loading, updates, fetchUpdates } = useLineItems();

  useEffect(() => {
    cartTotals.forEach((cartTotal) => {
      cartTotal.innerHTML = window.formatMoney(cartData.total_price);
    });
    if (loading) {
      loadingSpinner.forEach((spinner) => spinner.classList.remove("opacity-0"));
    }
    if (!loading) {
      loadingSpinner.forEach((spinner) => spinner.classList.add("opacity-0"));
    }
    cartCountItems.forEach((cartCounter) => {
      cartCounter.innerHTML = `${cartData.item_count}`;
    });
  }, [loading, cartData, cartTotals, loadingSpinner, cartCountItems]);

  useDebouncedEffect(
    () => {
      if (updates !== null) {
        fetchUpdates();
      }
    },
    800,
    [updates]
  );

  useEffect(() => {
    document.addEventListener("cart:add", initCart);
    return () => {
      document.removeEventListener("cart:add", initCart);
    };
  }, []);

  useEffect(() => {
    if (hydrated) {
      cartData.items.forEach((item) => {
        preloadProduct(item.product_id, `/products/${item.handle}`);
      });
    }
  }, [cartData.items, hydrated, preloadProduct]);

  useEffect(() => {
    document
      .querySelectorAll<HTMLButtonElement>("[data-cart-checkout-button]")
      .forEach((buttonElement) => {
        buttonElement.disabled = cartData.item_count <= 0;
      });
  }, [cartData.item_count]);

  return null;
};

export const CartDrawerLineItem: FC<{ line_item: _Cart_fetch_api_Items }> = ({ line_item }) => {
  const { adjustItem } = useLineItems(({ adjustItem }) => ({ adjustItem: adjustItem }));
  const [variant, setVariant] = useState<_Variant_liquid>(null);
  const products = useGlobalProducts((state) => state.products);

  useEffect(() => {
    if (!variant && products[line_item.product_id]) {
      setVariant(
        products[line_item.product_id]?.variants?.find(({ id }) => id === line_item.variant_id)
      );
    }
  }, [line_item.product_id, line_item.variant_id, products, variant]);

  return (
    <article className="flex items-start space-x-5 border-b border-gray-200 py-6 sm:mx-4">
      <a className="relative block h-24 w-24 rounded-theme-sm" href={line_item.url}>
        <img
          src={`${line_item.image}&crop=center&height=100&width=100`}
          width="100"
          height="100"
          className={clsx(
            "h-full w-full object-cover",
            !line_item.image && "pointer-events-none hidden overflow-hidden opacity-0"
          )}
          alt={line_item.featured_image?.alt ?? line_item.title}
        />
      </a>
      <main className="flex flex-1 flex-col">
        <a className="hf:underline" href={line_item.url}>
          <h3 className="text-sm font-medium text-gray-900">{line_item.product_title}</h3>
        </a>

        <h4 className="text-xs text-gray-500 ">{line_item.variant_title}</h4>
        {Object.entries(line_item?.properties ?? {})
          ?.filter(([key]) => !/^_/gi.test(key))
          ?.map(([key, value]) => {
            if (key === "preorder") {
              return (
                <p key={key} className="mt-1 flex text-xs text-gray-600 opacity-70">
                  <TimerIcon className="mr-2 h-4 w-4" /> <span>{value}</span>
                </p>
              );
            }
            return (
              <p key={key} className="text-xs text-gray-600">
                {capitalize(key)}: {value}
              </p>
            );
          })}

        <div className="mt-1 text-sm font-medium">
          <span
            className={clsx(
              "text-gray-500 line-through",
              line_item.original_price === line_item.discounted_price &&
                "pointer-events-none hidden overflow-hidden opacity-0"
            )}
          >
            {window.formatMoney(line_item.original_price)}{" "}
          </span>
          <span className="text-gray-900">{window.formatMoney(line_item.final_price)}</span>
        </div>

        <div className="mr-auto mt-2 flex select-none space-x-2.5 rounded-theme border border-gray-300 px-1.5 py-0.5 text-[13px] font-semibold">
          <button
            type="button"
            className="flex items-center justify-center p-1.5 text-gray-600 hf:text-gray-900"
            onClick={() => adjustItem(line_item, -1)}
          >
            <span className="sr-only">Decrease quantity by 1</span>
            <MinusIcon className="h-2 w-2 stroke-2" />
          </button>
          <span className="text-gray-800">{line_item.quantity}</span>
          <button
            type="button"
            onClick={() => adjustItem(line_item, 1)}
            className="flex items-center justify-center p-1.5 text-gray-600 hf:text-gray-900"
            disabled={
              variant?.inventory_policy === "deny" &&
              variant?.inventory_management === "shopify" &&
              variant?.inventory_quantity - line_item.quantity <= 0
            }
          >
            <span className="sr-only">Increase quantity by 1</span>
            <PlusIcon className="h-2 w-2 stroke-2" />
          </button>
        </div>
      </main>

      <button
        type="button"
        className="ml-auto flex rounded-theme p-2 text-gray-500 transition-all hf:text-gray-900 "
        onClick={() => adjustItem(line_item, -line_item.quantity)}
      >
        <span className="sr-only">Remove item from Cart</span>
        <CloseIcon className="h-3 w-3 stroke-2" />
      </button>
    </article>
  );
};

export const initLineItems = async () => {
  const cartDrawerLineItems = document.querySelector<HTMLElement>("[data-cart-drawer-line-items]");
  const cartLineItems = document.querySelector<HTMLElement>("[data-cart-line-items]");
  const cartSideEffects = document.querySelector<HTMLElement>("[data-cart-side-effects]");
  await cartDrawer.getState().initCart();
  cartDrawerLineItems.innerHTML = "";

  if (cartDrawerLineItems) {
    render(<CartDrawerLineItems />, cartDrawerLineItems);
  }
  if (cartLineItems) {
    render(<CartLineItems />, cartLineItems);
  }
  if (cartSideEffects) {
    render(<CartSideEffects />, cartSideEffects);
  }
};

export const initCart = () => {
  initAnnouncementBars();
  initFreeShippingBar();
  initLineItems();
  initPromotionalItems();
};

function initAnnouncementBars() {
  const announcementBars = document.querySelectorAll<HTMLElement>(
    "[data-announcement-bar]:not([data-initiated])"
  );

  announcementBars.forEach((announcementBar) => {
    announcementBar.setAttribute("data-initiated", "");
    let activeIndex = 0;

    displayAnnouncements();

    function displayAnnouncements() {
      [...announcementBar.querySelectorAll<HTMLElement>("[data-announcement-index]")].forEach(
        (announcement, i, arr) => {
          const index = +announcement.dataset.announcementIndex;
          const duration = +announcement.dataset.announcementDuration;
          const textColor = announcement.dataset.announcementText;
          const bgColor = announcement.dataset.announcementBg;

          if (arr.length === 1) {
            announcementBar.style.setProperty("--color-bg-hex", bgColor);
            announcementBar.style.setProperty("--color-text-hex", textColor);
            announcement.style.opacity = "1";
            announcement.style.pointerEvents = "auto";
            return;
          }

          if (activeIndex === index) {
            announcementBar.style.setProperty("--color-bg-hex", bgColor);
            announcementBar.style.setProperty("--color-text-hex", textColor);
            announcement.style.opacity = "1";
            announcement.style.pointerEvents = "auto";
            setTimeout(
              () => {
                activeIndex = activeIndex + 1 === arr.length ? 0 : activeIndex + 1;
                displayAnnouncements();
              },
              duration * 1000
            );
          }

          if (activeIndex !== index) {
            announcement.style.opacity = "0";
            announcement.style.pointerEvents = "none";
            announcement.tabIndex = -1;
          }
        }
      );
    }
  });
}

function initFreeShippingBar() {
  document
    .querySelectorAll<HTMLElement>("[data-free-shipping-bar-target]:not([data-initiated])")
    .forEach((shippingBar) => {
      shippingBar.setAttribute("data-initiated", "");

      const target = +shippingBar.dataset.freeShippingBarTarget;
      const type = shippingBar.dataset.freeShippingBarType as "item_count" | "total_price";
      const content = shippingBar.querySelector<HTMLElement>("[data-free-shipping-bar-content]");
      const percentageSlider = shippingBar.querySelector<HTMLElement>(
        "[data-free-shipping-bar-percentage]"
      );

      document.addEventListener("cart:update", (event: CustomEvent<_Cart_fetch_api>) => {
        const current = event.detail[type];
        const difference = Math.max(target - current, 0);
        const percentage = Math.min((current / target) * 100, 100);
        percentageSlider.style.width = `${percentage}%`;

        /* TODO: Content in JS is not a great idea!! */
        if (percentage === 100) {
          content.innerHTML = "YOU'VE GOT FREE SHIPPING!";
        }
        if (percentage < 100 && type === "item_count") {
          content.innerHTML = `ADD ${difference} ITEMS MORE FOR FREE SHIPPING!`;
        }
        if (percentage < 100 && type === "total_price") {
          content.innerHTML = `ADD ${window.formatMoney(difference)} MORE FOR FREE SHIPPING!`;
        }
      });
    });
}

function PromotionalItems({ settings }: { settings: CartDrawerSection["settings"] }) {
  const { cartData } = useLineItems();
  const { preloadProduct, getProduct, hydrated } = useGlobalProducts(
    ({ preloadProduct, getProduct, hydrated }) => ({
      preloadProduct,
      getProduct,
      hydrated,
    })
  );
  const { updateDrawerProduct } = useProductDrawer((state) => ({
    updateDrawerProduct: state?.updateProduct,
  }));

  const products = useMemo(() => {
    if (!cartData?.items || !hydrated) {
      return [...settings.cart__recommended_products];
    }

    const unfilteredCartItems = [
      ...cartData.items
        .slice(0)
        .reverse()
        .map((item) => getProduct(item.product_id))
        .filter((p) => p)
        .map(
          (product) =>
            (product.metafields?.["shopify--discovery--product_recommendation"]
              ?.complementary_products ?? []) as _Product_liquid[]
        )
        .flat(),
      ...settings.cart__recommended_products,
    ]?.filter((p) => !cartData.items.some((item) => +item.product_id === +p.id));

    return unfilteredCartItems?.filter(
      (p, index) => unfilteredCartItems.findIndex((p2) => p2.id === p.id) === index
    );
  }, [cartData?.items, getProduct, hydrated, settings.cart__recommended_products]);

  const handleViewComplementaryProduct = useCallback(async (e, upsellProduct: _Product_liquid) => {
    if (updateDrawerProduct) {
      e.preventDefault();
      updateDrawerProduct(getProduct(upsellProduct.id));
      // document.dispatchEvent(new Event("product:open"));
      setTimeout(() => document.dispatchEvent(new Event("product:open")), 1);
    }
  }, [getProduct, updateDrawerProduct]);

  useEffect(() => {
    if (hydrated) {
      products.forEach((product) => {
        preloadProduct(product.id, `/products/${product.handle}`);
      });
    }
  }, [hydrated, preloadProduct, products]);

  return (
    <>
      {products.length
        ? <div
            className="scrollbar-none -my-8 grid snap-x snap-mandatory scroll-pl-8 grid-flow-col-dense gap-6 overflow-x-auto scroll-smooth py-8 "
            style={{ gridAutoColumns: "170px" }}
          >
            {products?.slice(0, 5).map((upsellProduct) => {
              return (
                <article
                  key={upsellProduct.id}
                  className="relative flex flex-col items-stretch space-y-1 "
                >
                  <a
                    className="relative grid h-0 w-full pb-[100%] outline-none hf:outline-none"
                    href={`/products/${upsellProduct.handle}`}
                  >
                    <div
                      className={clsx(
                        "absolute inset-0 h-full w-full overflow-hidden",
                        !upsellProduct.featured_image && "opacity-0"
                      )}
                      style={{ background: "transparent" }}
                    >
                      <img
                        src={`${upsellProduct.featured_image}?v=1667663357&width=200`}
                        alt={upsellProduct.title}
                        width="170"
                        height="334"
                        className="inset-0 h-full w-full object-cover "
                      />
                    </div>
                    {upsellProduct.images[1]
                      ? <div className="absolute inset-0 h-full w-full overflow-hidden opacity-0 transition-all duration-75 hf:opacity-100">
                          <img
                            src={`${upsellProduct.images[1]}?v=1667663357&width=200`}
                            alt={upsellProduct.title}
                            width="170"
                            height="334"
                            className="inset-0 h-full w-full object-cover "
                          />
                        </div>
                      : null}

                    {upsellProduct.variants.length > 1
                      ? <div className="pointer-events-none absolute left-1/2 bottom-6 -translate-x-1/2 text-center text-xs tracking-wide text-theme-bg drop-shadow ">
                          Available in {upsellProduct.variants.length} variations
                        </div>
                      : null}
                  </a>

                  <h1 className=" inline-flex pt-2 text-sm font-semibold leading-[1.2] tracking-tight tracking-tight">
                    <a
                      className="outline-none hf:underline hf:outline-none"
                      href={`/products/${upsellProduct.handle}`}
                    >
                      {upsellProduct.title}
                    </a>
                  </h1>

                  <div className="text-xl" data-card-price="">
                    <div className=" grid auto-cols-min grid-flow-col-dense items-baseline gap-2 whitespace-nowrap text-sm font-semibold">
                      {upsellProduct.price_varies &&
                      upsellProduct.compare_at_price_min < upsellProduct.price_min
                        ? <span className="text-xs font-normal">On Sale from:</span>
                        : upsellProduct.price_varies
                        ? <span className="text-xs font-normal">From:</span>
                        : null}
                      <span className="">{window.formatMoney(upsellProduct.price_min)}</span>
                      {upsellProduct.compare_at_price > upsellProduct.price
                        ? <span className="text-xs text-theme-text/50 line-through">
                            {window.formatMoney(upsellProduct.compare_at_price)}
                          </span>
                        : null}
                    </div>
                  </div>

                  <div className="mt-auto mt-2 flex w-full flex-1 flex-col justify-end self-end text-center">
                    <a
                      className="button-primary mt-2 w-full px-3 py-1 text-sm outline-none hf:outline-none"
                      href={`/products/${upsellProduct.handle}`}
                      onClick={(e) => handleViewComplementaryProduct(e, upsellProduct)}
                    >
                      {upsellProduct.available
                        ? <span className="whitespace-nowrap">View</span>
                        : <span className="">Sold Out</span>}
                    </a>
                  </div>
                </article>
              );
            })}
            <ScrollBar itemCount={products.length} />
          </div>
        : null}
    </>
  );
}

function initPromotionalItems() {
  const promotionalItems = document.querySelector<HTMLElement>("[data-cart-promotion-items]");
  const settings = JSONParse(promotionalItems.querySelector("[data-section-settings]")?.innerHTML);
  render(
    <PromotionalItems settings={settings as CartDrawerSection["settings"]} />,
    promotionalItems
  );
}
