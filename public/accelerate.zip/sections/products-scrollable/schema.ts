import { buttons } from "globals/settings/buttons";
import { productCardSettings } from "globals/settings/product-card-settings";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { ProductsScrollableSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const productsScrollable: ShopifySection<ProductsScrollableSection> = {
  name: "Products scrollable",
  generate_block_files: ["heading", "view_all_bar"],
  settings: [
    {
      type: "select",
      id: "product_source",
      label: "Product Source",
      default: "blocks",
      options: [
        {
          value: "blocks",
          label: "Blocks",
        },
        {
          value: "recently_viewed_products",
          label: "Recently Viewed Products",
        },
      ],
    },
    {
      type: "range",
      id: "product_limit",
      label: "Product limit",
      default: 12,
      min: 4,
      max: 24,
      step: 1,
    },
    {
      type: "checkbox",
      id: "hide_out_of_stock",
      label: "Hide out of stock Products",
    },
    {
      type: "checkbox",
      id: "hide_if_empty",
      label: "Hide Section if empty",
      info: "The section will always show in the Theme Editor to enable easy customization.",
    },
    {
      type: "header",
      content: "Layout",
    },
    {
      type: "checkbox",
      id: "container_overflow",
      label: "Fill fullscreen when scrolling",
    },
    {
      type: "checkbox",
      id: "center_products",
      label: "Center Products if less than width",
    },
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "heading",
      name: "Heading",
      limit: 1,
      settings: [
        {
          type: "header",
          content: "Content",
        },
        {
          type: "text",
          id: "preheading",
          label: "Pre heading",
        },
        typeRange({ id: "preheading_font", label: "Pre heading style", default_font: 3 }),
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        typeRange({ id: "title_font", label: "Title style", default_font: 1 }),
        {
          type: "textarea",
          id: "subtitle",
          label: "Subtitle",
        },
        typeRange({ id: "subtitle_font", label: "Subtitle style", default_font: 2 }),
        {
          type: "richtext",
          id: "content",
          label: "Richtext",
        },
        ...buttons.primary,
        ...buttons.secondary,
        {
          type: "header",
          content: "Layout",
        },
        {
          type: "radio",
          id: "align__horizontal",
          label: "Horizontal Alignment",
          default: "items-center text-center",
          options: [
            {
              value: "items-start text-left",
              label: "Left",
            },
            {
              value: "items-center text-center",
              label: "Center",
            },
            {
              value: "items-end text-right",
              label: "Right",
            },
          ],
        },
        {
          type: "range" as const,
          id: "margin_bottom",
          label: "Margin Bottom",
          default: 0,
          min: -6,
          max: 42,
          step: 2,
          unit: "px",
        },
      ],
    },
    {
      type: "view_all_bar",
      name: "View all bar",
      limit: 1,
      settings: [
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        typeRange({ id: "title_font", label: "Title style", default_font: 1 }),
        {
          type: "url",
          id: "url",
          label: "Url",
        },
        {
          type: "range" as const,
          id: "margin_bottom",
          label: "Margin Bottom",
          default: 0,
          min: -6,
          max: 42,
          step: 2,
          unit: "px",
        },
      ],
    },
    {
      type: "source_products",
      name: "Source: Product List",
      limit: 1,
      settings: [
        {
          type: "product_list",
          id: "source",
          label: "Products",
        },
      ],
    },
    {
      type: "source_collection",
      name: "Source: Collection",
      limit: 1,
      settings: [
        {
          type: "collection",
          id: "source",
          label: "Collection",
        },
      ],
    },
    {
      type: "source_metafield",
      name: "Source: Metafield Selector",
      limit: 1,
      settings: [
        {
          type: "text",
          id: "source",
          label: "Metafield Namespace & Key",
          placeholder: "accelerate.related_products",
          default: "shopify--discovery--product_recommendation.complementary_products",
        },
      ],
    },
  ],

  presets: [
    {
      name: "Products scrollable",
      blocks: [
        { type: "heading" },
        { type: "source_products" },
        { type: "source_collection" },
        { type: "source_metafield" },
      ],
    },
  ],
};
