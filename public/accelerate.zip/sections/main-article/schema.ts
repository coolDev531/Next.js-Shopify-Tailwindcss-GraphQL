import { MainArticleSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainArticle: ShopifySection<MainArticleSection> = {
  name: "Blog post",
  disabled_block_files: true,
  blocks: [
    {
      type: "@app",
    },
    {
      type: "featured_image",
      name: "Featured image",
      limit: 1,
      settings: [
        {
          type: "select",
          id: "image_height",
          options: [
            {
              value: "adapt",
              label: "Adapt to image",
            },
            {
              value: "small",
              label: "Small",
            },
            {
              value: "medium",
              label: "Medium",
            },
            {
              value: "large",
              label: "Large",
            },
          ],
          default: "adapt",
          label: "Featured image height",
          info: "For best results, use an image with a 16:9 aspect ratio. [Learn more](https://help.shopify.com/manual/shopify-admin/productivity-tools/image-editor#understanding-image-aspect-ratio)",
        },
      ],
    },
    {
      type: "title",
      name: "Title",
      limit: 1,
      settings: [
        {
          type: "checkbox",
          id: "blog_show_date",
          default: true,
          label: "Show date",
        },
        {
          type: "checkbox",
          id: "blog_show_author",
          default: false,
          label: "Show author",
        },
      ],
    },
    {
      type: "content",
      name: "Content",
      limit: 1,
    },
    {
      type: "share",
      name: "Share",
      limit: 2,
      settings: [
        {
          type: "text",
          id: "share_label",
          label: "Text",
          default: "Share",
        },
        {
          type: "paragraph",
          content:
            "If you include a link in social media posts, the page’s featured image will be shown as the preview image. [Learn more](https://help.shopify.com/manual/online-store/images/showing-social-media-thumbnail-images).",
        },
        {
          type: "paragraph",
          content:
            "A store title and description are included with the preview image. [Learn more](https://help.shopify.com/manual/promoting-marketing/seo/adding-keywords#set-a-title-and-description-for-your-online-store).",
        },
      ],
    },
  ],
};
