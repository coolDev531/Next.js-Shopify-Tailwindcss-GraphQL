import { ShopifySection } from "types/shopify";
import { ProductSiblingsSection } from "types/sections";

export const productSiblings: ShopifySection<ProductSiblingsSection> = {
  name: "Product sibling Groups",
  disabled_block_files: true,
  max_blocks: 10,
  settings: [
    {
      type: "paragraph",
      content:
        "You can setup up to 10 Product Sibling groups here. Make sure that you include the siblings block within the product information section.",
    },
  ],
  blocks: [
    {
      type: "siblings",
      name: "Siblings Group",
      settings: [
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        {
          type: "product_list",
          id: "products",
          label: "Products",
        },
        {
          type: "textarea",
          id: "options",
          label: "Options",
          info: "Comma seperated list of the options title in the same order as the selected products. Fallback is the product titel",
        },
      ],
    },
  ],
};
