import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { MainCollectionBannerSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainCollectionBanner: ShopifySection<MainCollectionBannerSection> = {
  name: "Collection banner",
  class: "relative",
  settings: [
    {
      type: "paragraph",
      content:
        "Add a description or image by editing your collection. [Learn more](https://help.shopify.com/manual/products/collections/collection-layout)",
    },
    {
      type: "checkbox",
      id: "image__show",
      default: false,
      label: "Show collection image",
      info: "For best results, use an image with a 16:9 aspect ratio. [Learn more](https://help.shopify.com/manual/shopify-admin/productivity-tools/image-editor#understanding-image-aspect-ratio)",
    },
    {
      type: "color_background",
      id: "image__overlay",
      label: "Overlay",
      default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
    },
    {
      type: "header",
      content: "Layout",
    },
    {
      type: "range",
      id: "height_desktop",
      label: "Desktop min height",
      default: 240,
      min: 180,
      max: 600,
      step: 10,
      unit: "px",
    },
    {
      type: "range",
      id: "height_mobile",
      label: "Mobile min height",
      default: 240,
      min: 180,
      max: 600,
      step: 10,
      unit: "px",
    },

    {
      type: "radio",
      id: "align__vertical",
      label: "Vertical Alignment",
      default: "justify-center",
      options: [
        {
          value: "justify-start",
          label: "Top",
        },
        {
          value: "justify-center",
          label: "Center",
        },
        {
          value: "justify-end",
          label: "Bottom",
        },
      ],
    },
    {
      type: "radio",
      id: "align__horizontal",
      label: "Horizontal Alignment",
      default: "items-center text-center",
      options: [
        {
          value: "items-start text-left",
          label: "Left",
        },
        {
          value: "items-center text-center",
          label: "Center",
        },
        {
          value: "items-end text-right",
          label: "Right",
        },
      ],
    },
    sectionGlobals.sectionLayout,
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "title",
      name: "Title",
      limit: 1,
      settings: [
        typeRange({ id: "title_type", label: "Type", default_font: 1 }),
        {
          type: "header" as const,
          content: "Layout",
        },
        {
          type: "range" as const,
          id: "margin_bottom",
          label: "Margin Bottom",
          default: 0,
          min: -6,
          max: 42,
          step: 2,
          unit: "px",
        },
        sectionGlobals.responsiveVisibility,
      ],
    },
    {
      type: "description",
      name: "Description",
      limit: 1,
      settings: [
        typeRange({ id: "title_type", label: "Type", default_font: 7 }),
        {
          type: "header" as const,
          content: "Layout",
        },
        {
          type: "range" as const,
          id: "margin_bottom",
          label: "Margin Bottom",
          default: 0,
          min: -6,
          max: 42,
          step: 2,
          unit: "px",
        },
        sectionGlobals.responsiveVisibility,
      ],
    },
    {
      type: "product_count",
      name: "Product Count",
      limit: 1,
      settings: [
        typeRange({ id: "title_type", label: "Type", default_font: 5 }),
        {
          type: "header" as const,
          content: "Layout",
        },
        {
          type: "range" as const,
          id: "margin_bottom",
          label: "Margin Bottom",
          default: 0,
          min: -6,
          max: 42,
          step: 2,
          unit: "px",
        },
        sectionGlobals.responsiveVisibility,
      ],
    },
  ],
};
