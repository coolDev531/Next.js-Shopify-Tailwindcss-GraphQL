import { buttons } from "globals/settings/buttons";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { SlideshowSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const slideshow: ShopifySection<SlideshowSection> = {
  name: "Slideshow",
  settings: [
    {
      type: "checkbox",
      id: "fullscreen",
      label: "Full width",
      default: true,
    },
    {
      type: "range",
      id: "height",
      label: "Height",
      default: 300,
      min: 200,
      max: 800,
      step: 20,
      unit: "px",
    },
    {
      type: "checkbox",
      id: "auto_rotate",
      label: "Auto-rotate slides",
      default: false,
    },
    {
      type: "range",
      id: "slide_speed",
      min: 3,
      max: 20,
      step: 1,
      unit: "s",
      label: "Change slides every",
      default: 5,
    },
  ],
  blocks: [
    {
      type: "slide",
      name: "Slide",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "Image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(134deg, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "Content",
        },
        {
          type: "text",
          id: "preheading",
          label: "Pre heading",
        },
        typeRange({ id: "preheading_font", label: "Pre heading style", default_font: 3 }),
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        typeRange({ id: "title_font", label: "Title style", default_font: 1 }),
        {
          type: "textarea",
          id: "subtitle",
          label: "Subtitle",
        },
        typeRange({ id: "subtitle_font", label: "Subtitle style", default_font: 2 }),
        {
          type: "richtext",
          id: "content",
          label: "Richtext",
        },
        ...buttons.primary,
        ...buttons.secondary,
        {
          type: "header",
          content: "Layout",
        },
        {
          type: "radio",
          id: "align__vertical",
          label: "Vertical Alignment",
          default: "justify-center",
          options: [
            {
              value: "justify-start",
              label: "Top",
            },
            {
              value: "justify-center",
              label: "Center",
            },
            {
              value: "justify-end",
              label: "Bottom",
            },
          ],
        },
        {
          type: "radio",
          id: "align__horizontal",
          label: "Horizontal Alignment",
          default: "items-center text-center",
          options: [
            {
              value: "items-start text-left",
              label: "Left",
            },
            {
              value: "items-center text-center",
              label: "Center",
            },
            {
              value: "items-end text-right",
              label: "Right",
            },
          ],
        },
        {
          type: "checkbox",
          id: "slide",
          label: "Use Individual Slide Speed",
        },
        {
          type: "range",
          id: "slide_speed",
          min: 3,
          max: 20,
          step: 1,
          unit: "s",
          label: "Change slides every",
          default: 5,
        },
        sectionGlobals.responsiveVisibility,
        sectionGlobals.colorScheme,
      ],
    },
  ],

  presets: [
    {
      name: "Slideshow",
    },
  ],
};
