import { buttons } from "globals/settings/buttons";
import { contentBlocks } from "globals/settings/content-blocks";
import { sectionGlobals } from "globals/settings/section-globals";
import { typeRange } from "globals/settings/type-range";
import { ObjectOverImageSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const objectOverImage: ShopifySection<ObjectOverImageSection> = {
  name: "Object over image",
  generate_block_files: ["object"],
  settings: [
    typeRange({ id: "title_type", label: "Title Type" }),
    {
      type: "header",
      content: "Layout",
    },
    {
      type: "range",
      id: "spacing",
      label: "Spacing",
      default: 16,
      min: 0,
      max: 96,
      step: 4,
      unit: "px",
    },
    sectionGlobals.responsiveVisibility,
    sectionGlobals.topPadding,
    sectionGlobals.bottomPadding,
    sectionGlobals.colorScheme,
  ],
  blocks: [
    {
      type: "object_position",
      name: "Object Position",
      limit: 1,
      settings: [
        {
          type: "header" as const,
          content: "Layout",
        },
        sectionGlobals.marginBottom,
      ],
    },
    {
      type: "object",
      name: "Object Item",
      limit: 3,
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "content",
        },
        {
          type: "url",
          id: "url",
          label: "Url",
          info: "Link to a Product, Collection or Article to set the default image and title.",
        },
        {
          type: "header",
          content: "Optional Content",
        },
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        ...buttons.primary,
        ...buttons.secondary,
        {
          type: "header",
          content: "layout",
        },
        sectionGlobals.responsiveVisibility,
      ],
    },
    contentBlocks.text,
    contentBlocks.accentLine,
    contentBlocks.buttonGroup,
    /*{
      type: "product",
      name: "Product",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "content",
        },
        {
          type: "product",
          id: "object",
          label: "Product",
        },
      ],
    },
    {
      type: "collection",
      name: "Collection",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "content",
        },
        {
          type: "collection",
          id: "object",
          label: "Collection",
        },
      ],
    },
    {
      type: "article",
      name: "Article",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "content",
        },
        {
          type: "article",
          id: "object",
          label: "Article",
        },
      ],
    },
    {
      type: "page",
      name: "Page",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "content",
        },
        {
          type: "page",
          id: "object",
          label: "Page",
        },
      ],
    },
    {
      type: "manual",
      name: "Manual",
      settings: [
        {
          type: "header",
          content: "Image",
        },
        {
          type: "image_picker",
          id: "image",
          label: "image",
        },
        {
          type: "color_background",
          id: "image__overlay",
          label: "Overlay",
          default: "linear-gradient(180deg, rgba(0, 0, 0, 0.15), rgba(0, 0, 0, 0.05) 100%)",
        },
        {
          type: "header",
          content: "content",
        },
        {
          type: "text",
          id: "title",
          label: "Title",
        },
        {
          type: "text",
          id: "button_primary__text",
          label: "Primary Button",
        },
        {
          type: "url",
          id: "button_primary__url",
          label: "Primary Button Link",
        },
        {
          type: "text",
          id: "button_secondary__text",
          label: "Secondary Button",
        },
        {
          type: "url",
          id: "button_secondary__url",
          label: "Secondary Button Link",
        },
      ],
    },*/
  ],
  presets: [
    {
      name: "Object over image",
    },
  ],
};
