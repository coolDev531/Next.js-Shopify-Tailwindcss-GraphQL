import { PredictiveSearchSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const predictiveSearch: ShopifySection<PredictiveSearchSection> = {
  name: "Predictive search",
  settings: [],
};
