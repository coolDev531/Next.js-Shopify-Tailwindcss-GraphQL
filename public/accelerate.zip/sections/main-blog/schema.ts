import { sectionGlobals } from "globals/settings/section-globals";
import { productCardSettings } from "globals/settings/product-card-settings";
import { MainBlogSection } from "types/sections";
import { ShopifySection } from "types/shopify";

export const mainBlog: ShopifySection<MainBlogSection> = {
  name: "Blog posts",
  settings: [
    {
      type: "header",
      content: "Blog post card",
    },
    {
      type: "checkbox",
      id: "image__show",
      default: true,
      label: "Show featured image",
    },
    productCardSettings.image__ratio,
    productCardSettings.image__background,
    {
      type: "checkbox",
      id: "date__show",
      default: true,
      label: "Show date",
    },
    {
      type: "checkbox",
      id: "author__show",
      default: false,
      label: "Show author",
    },
    {
      type: "paragraph",
      content:
        "Change excerpts by editing your blog posts. [Learn more](https://help.shopify.com/manual/online-store/blogs/writing-blogs#display-an-excerpt-from-a-blog-post)",
    },
    sectionGlobals.colorScheme,
  ],
};
