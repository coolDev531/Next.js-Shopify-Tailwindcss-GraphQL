import fs from "fs";
import path from "path";
import watch from "node-watch";
import theme from "tailwindcss/defaultTheme";
require("dotenv").config();

export {};

const { SHOPIFY_THEME_FOLDER } = process.env;

watch(path.join(process.cwd(), "theme", "assets"), { recursive: true }, async (evt, name) => {
  if (!name.match(/\.(ts)$/)) return;

  const files = fs.readdirSync(path.join(process.cwd(), SHOPIFY_THEME_FOLDER, "assets"));

  files.forEach((file) => {
    if (!file.match(/\.(js)$/)) return;
    const fileName = path.join(process.cwd(), SHOPIFY_THEME_FOLDER, "assets", file);

    const content = fs.readFileSync(fileName, { encoding: "utf-8" });
    const newContent = content.replace(/from "([^"]*\.js)"/gi, (match, matchGroup) => {
      return `from "${matchGroup}?v=${Date.now()}"`;
    });
    fs.writeFileSync(fileName, newContent);
    console.log(`updated: ${file}`);
  });
});
